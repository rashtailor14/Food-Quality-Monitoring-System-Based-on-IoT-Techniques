package com.leakhead.foodqualityapp.ui.charts

import android.support.v7.widget.LinearLayoutManager
import com.leakhead.foodqualityapp.ui.charts.adapter.ChartsHistoryListAdapter
import com.leakhead.foodqualityapp.ui.charts.fragments.ChartsFragment
import com.leakhead.foodqualityapp.ui.food.history.interactor.FoodHistoryInteractor
import com.leakhead.foodqualityapp.ui.food.history.interactor.FoodHistoryMVPInteractor
import com.leakhead.foodqualityapp.ui.food.history.presenter.FoodHistoryMVPPresenter
import com.leakhead.foodqualityapp.ui.food.history.presenter.FoodHistoryPresenter
import com.leakhead.foodqualityapp.ui.food.history.view.FoodHistoryFragment
import com.leakhead.foodqualityapp.ui.food.history.view.FoodHistoryMVPView
import dagger.Module
import dagger.Provides
import java.util.*

/**
 * Created by jyotidubey on 14/01/18.
 */
@Module
class ChartsFragmentModule {

    @Provides
    internal fun provideChartsInteractor(interactor: FoodHistoryInteractor): FoodHistoryMVPInteractor = interactor

    @Provides
    internal fun provideChartsPresenter(presenter: FoodHistoryPresenter<FoodHistoryMVPView, FoodHistoryMVPInteractor>)
            : FoodHistoryMVPPresenter<FoodHistoryMVPView, FoodHistoryMVPInteractor> = presenter

    @Provides
    internal fun provideChartsAdapter(): ChartsHistoryListAdapter = ChartsHistoryListAdapter(ArrayList())

    @Provides
    internal fun provideLinearLayoutManager(fragment: ChartsFragment): LinearLayoutManager =
        LinearLayoutManager(fragment.activity)

}