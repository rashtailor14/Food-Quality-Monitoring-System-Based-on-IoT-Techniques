package com.leakhead.foodqualityapp.ui.charts.fragments

import android.os.Bundle
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.data.database.repository.history.FoodHistory
import com.leakhead.foodqualityapp.ui.GlobalValues
import com.leakhead.foodqualityapp.ui.base.view.BaseFragment
import com.leakhead.foodqualityapp.ui.charts.adapter.ChartsHistoryListAdapter
import com.leakhead.foodqualityapp.ui.charts.interactor.ChartsMVPInteractor
import com.leakhead.foodqualityapp.ui.charts.presenter.ChartsMVPPresenter
import com.leakhead.foodqualityapp.ui.charts.view.ChartsMVPView
import kotlinx.android.synthetic.main.fragment_anylytics_history.*
import org.json.JSONObject
import javax.inject.Inject

/**
 * Created by user on 25-February-2020
 */
class ChartsFragment : BaseFragment(), ChartsMVPView {

    companion object {

        internal val TAG = "ChartsFragment"

        fun newInstance(): ChartsFragment {
            return ChartsFragment()
        }
    }

    @Inject
    internal lateinit var listAdapter: ChartsHistoryListAdapter
    @Inject
    internal lateinit var layoutManager: LinearLayoutManager
    @Inject
    internal lateinit var presenter: ChartsMVPPresenter<ChartsMVPView, ChartsMVPInteractor>


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
        inflater.inflate(R.layout.fragment_anylytics_history, container, false)


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        presenter.onAttach(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun setUp() {
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        anylytics_history_recycler_view.layoutManager = layoutManager
        anylytics_history_recycler_view.itemAnimator = DefaultItemAnimator()
        anylytics_history_recycler_view.adapter = listAdapter
//        presenter.onViewPrepared()

        val jsonObject = JSONObject()

        jsonObject.put("myHost", GlobalValues.ipAddress)
        jsonObject.put("myPort", GlobalValues.port)
        jsonObject.put("myDB", GlobalValues.db)

        presenter.onViewPreparedHistory(jsonObject)
    }

    override fun displayFoodHistoryList(foodHistory: List<FoodHistory>?) = foodHistory?.let {
        //        blogAdapter.addFoodHistoryToList(it)
    }

    override fun displayFoodHistoryListData(foodHistory: List<String>) {
        listAdapter.addFoodHistoryToList(foodHistory)
    }

    override fun onDestroyView() {
        presenter.onDetach()
        super.onDestroyView()
    }
}