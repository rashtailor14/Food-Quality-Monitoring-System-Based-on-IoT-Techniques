package com.leakhead.foodqualityapp.ui.charts.view

import android.os.Bundle
import android.support.v4.app.Fragment
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.data.database.repository.history.FoodHistory
import com.leakhead.foodqualityapp.ui.base.view.BaseActivity
import com.leakhead.foodqualityapp.ui.charts.fragments.ChartsFragment
import com.leakhead.foodqualityapp.ui.charts.interactor.ChartsMVPInteractor
import com.leakhead.foodqualityapp.ui.charts.presenter.ChartsMVPPresenter
import com.leakhead.foodqualityapp.util.extension.addFragment
import dagger.android.DispatchingAndroidInjector
import dagger.android.support.HasSupportFragmentInjector
import javax.inject.Inject

/**
 * Created by user on 25-February-2020
 */
class ChartsActivity : BaseActivity(), ChartsMVPView, HasSupportFragmentInjector {

    @Inject
    internal lateinit var presenter: ChartsMVPPresenter<ChartsMVPView, ChartsMVPInteractor>

    @Inject
    internal lateinit var fragmentDispatchingAndroidInjector: DispatchingAndroidInjector<Fragment>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_charts)
        presenter.onAttach(this)

        supportFragmentManager.addFragment(
            R.id.fragment_container_charts,
            ChartsFragment.newInstance(),
            ChartsFragment.TAG
        )

    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    override fun onFragmentDetached(tag: String) {
    }

    override fun onFragmentAttached() {
    }

    override fun displayFoodHistoryList(foodHistory: List<FoodHistory>?) {

    }

    override fun displayFoodHistoryListData(foodHistory: List<String>) {

    }

    override fun supportFragmentInjector() = fragmentDispatchingAndroidInjector
}