package com.leakhead.foodqualityapp.ui.charts.view

import android.graphics.Color
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.common.Priority
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.JSONObjectRequestListener
import com.github.mikephil.charting.components.AxisBase
import com.github.mikephil.charting.components.Description
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.ui.GlobalValues
import kotlinx.android.synthetic.main.activity_chart_description.*
import org.json.JSONObject


class ChartDescriptionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chart_description)

        val sessionId = intent.getStringExtra("testId")

        if (!sessionId.isNullOrEmpty()) {
            getData(sessionId)
        }

    }

    fun getData(testId: String) {
        val jsonObject = JSONObject()

        jsonObject.put("dataId", testId)
        jsonObject.put("myHost", GlobalValues.ipAddress)
        jsonObject.put("myPort", GlobalValues.port)
        jsonObject.put("myDB", GlobalValues.db)

        AndroidNetworking.post("${GlobalValues.currentIPAddress}/getSensorInfo")
            .addJSONObjectBody(jsonObject)
            .setPriority(Priority.MEDIUM)
            .build()
            .getAsJSONObject(object : JSONObjectRequestListener {
                override fun onResponse(response: JSONObject) {
                    Log.d("dpnkrlog", "onResponse result (line 216):$response ")


                    prodNameTemp.text = response.getJSONObject("processMessage").getString("foodName")
                    prodNameMoi.text = response.getJSONObject("processMessage").getString("foodName")
                    prodNameAir.text = response.getJSONObject("processMessage").getString("foodName")
                    prodNamePh.text = response.getJSONObject("processMessage").getString("foodName")


//                    txt_type.text = response.getJSONObject("processMessage").getString("foodType")
//                    txt_date.text = response.getJSONObject("processMessage").getString("testDate")
                    val temp = response.getJSONObject("processMessage").getString("myTemprature")
                    val humidity = response.getJSONObject("processMessage").getString("moLevel")
                    val air = response.getJSONObject("processMessage").getString("airQuality")
                    val ph = response.getJSONObject("processMessage").getString("phValues")
//                    txt_color.text = response.getJSONObject("processMessage").getString("color")

                    populateMoistureData(humidity.toFloat())
                    setupTempChartData(temp.toFloat())
                    setupAirQualityData(air.toFloat())
                    setupPhQualityData(ph.toFloat())
                    // do anything with response
                }

                override fun onError(error: ANError) {
                    // handle error
                    Log.d("dpnkrlog", "error (line 216):$error ")
                }
            })
    }

    fun populateMoistureData(humidity: Float) {

        // data entry
        val phVal = 60.0f
        val yVals = ArrayList<Entry>()
        yVals.add(Entry(0f, phVal * 0, "0"))
        yVals.add(Entry(1f, phVal * 1, "1"))
        yVals.add(Entry(2f, phVal * 2, "2"))
        yVals.add(Entry(3f, phVal * 3, "3"))
        yVals.add(Entry(3f, phVal * 4, "4"))
        yVals.add(Entry(3f, phVal * 5, "5"))

        val yVal2 = ArrayList<Entry>()
        yVal2.add(Entry(0f, humidity * 0, "0"))
        yVal2.add(Entry(1f, humidity * 1, "1"))
        yVal2.add(Entry(2f, humidity * 2, "2"))
        yVal2.add(Entry(3f, humidity * 3, "3"))
        yVal2.add(Entry(3f, humidity * 4, "4"))
        yVal2.add(Entry(3f, humidity * 5, "5"))

        val set1: LineDataSet
        set1 = LineDataSet(yVals, "Threshold")

        val set2: LineDataSet
        set2 = LineDataSet(yVal2, "Actual")

        val phLeval = arrayOf("2", "4", "6", "8", "10", "12", "14")
        val time = arrayOf("20", "40", "60", "80")

        val formatter = object : ValueFormatter() {
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return time[value.toInt()]
            }
        }

        // set1.fillAlpha = 110
        // set1.setFillColor(Color.RED);

        // set the line to be drawn like this "- - - - - -"
        set1.enableDashedLine(5f, 5f, 0f);
        set1.enableDashedHighlightLine(10f, 5f, 0f);

        set1.color = Color.GREEN
        set1.setCircleColor(Color.GREEN)
        set1.lineWidth = 2f
        set1.circleRadius = 3f
        set1.setDrawCircleHole(false)
        set1.valueTextSize = 0f
        set1.setDrawFilled(false)

        val dataSets = ArrayList<ILineDataSet>()
        dataSets.add(set1)
        dataSets.add(set2)

        val data = LineData(dataSets)

        // set data
        chartConsumptionMos.setData(data)
        chartConsumptionMos.xAxis.setValueFormatter(formatter)

//        chartConsumptionPh.getAxisLeft().setAxisMaxValue(100f)
//        chartConsumptionPh.getAxisLeft().setAxisMinValue(0f)


//        chartConsumptionPh.setVisibleYRange(0f, 14f, YAxis.AxisDependency.LEFT)

        chartConsumptionMos.description.isEnabled = true
        val description = Description()
        val des = "Y Axis : Temp (deg Cen) \nX Axis : time(s)"
        description.setText(des)
        description.textSize = 18f
        description.textColor = Color.BLUE
        chartConsumptionMos.description = description

        chartConsumptionMos.legend.isEnabled = true
        chartConsumptionMos.setPinchZoom(true)
        chartConsumptionMos.xAxis.enableGridDashedLine(5f, 5f, 0f)
        chartConsumptionMos.axisRight.enableGridDashedLine(5f, 5f, 0f)
        chartConsumptionMos.axisLeft.enableGridDashedLine(5f, 5f, 0f)
        //lineChart.setDrawGridBackground()
        chartConsumptionMos.xAxis.labelCount = 11
        chartConsumptionMos.xAxis.position = XAxis.XAxisPosition.BOTTOM
    }

    private fun setupTempChartData(temp: Float) {
        // data entry
        val phVal = 1.1f
        val yVals = ArrayList<Entry>()
        yVals.add(Entry(0f, phVal * 0, "0"))
        yVals.add(Entry(1f, phVal * 1, "1"))
        yVals.add(Entry(2f, phVal * 2, "2"))
        yVals.add(Entry(3f, phVal * 3, "3"))
        yVals.add(Entry(3f, phVal * 4, "4"))
        yVals.add(Entry(3f, phVal * 5, "5"))

        val yVal2 = ArrayList<Entry>()
        yVal2.add(Entry(0f, temp * 0, "0"))
        yVal2.add(Entry(1f, temp * 1, "1"))
        yVal2.add(Entry(2f, temp * 2, "2"))
        yVal2.add(Entry(3f, temp * 3, "3"))
        yVal2.add(Entry(3f, temp * 4, "4"))
        yVal2.add(Entry(3f, temp * 5, "5"))

        val set1: LineDataSet
        set1 = LineDataSet(yVals, "Threshold")

        val set2: LineDataSet
        set2 = LineDataSet(yVal2, "Actual")

        val phLeval = arrayOf("2", "4", "6", "8", "10", "12", "14")
        val time = arrayOf("20", "40", "60", "80")

        val formatter = object : ValueFormatter() {
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return time[value.toInt()]
            }
        }

        // set1.fillAlpha = 110
        // set1.setFillColor(Color.RED);

        // set the line to be drawn like this "- - - - - -"
        set1.enableDashedLine(5f, 5f, 0f);
        set1.enableDashedHighlightLine(10f, 5f, 0f);

        set1.color = Color.GREEN
        set1.setCircleColor(Color.GREEN)
        set1.lineWidth = 2f
        set1.circleRadius = 3f
        set1.setDrawCircleHole(false)
        set1.valueTextSize = 0f
        set1.setDrawFilled(false)

        val dataSets = ArrayList<ILineDataSet>()
        dataSets.add(set1)
        dataSets.add(set2)

        val data = LineData(dataSets)

        // set data
        chartConsumptionTemp.setData(data)
        chartConsumptionTemp.xAxis.setValueFormatter(formatter)

//        chartConsumptionPh.getAxisLeft().setAxisMaxValue(100f)
//        chartConsumptionPh.getAxisLeft().setAxisMinValue(0f)


//        chartConsumptionPh.setVisibleYRange(0f, 14f, YAxis.AxisDependency.LEFT)
        chartConsumptionTemp.description.isEnabled = true
        val description = Description()
        val des = "Y Axis : Moisture Level (%) \nX Axis : time(s)"
        description.setText(des)
        description.textSize = 18f
        description.textColor = Color.BLUE
        chartConsumptionTemp.description = description

        chartConsumptionTemp.legend.isEnabled = true
        chartConsumptionTemp.setPinchZoom(true)
        chartConsumptionTemp.xAxis.enableGridDashedLine(5f, 5f, 0f)
        chartConsumptionTemp.axisRight.enableGridDashedLine(5f, 5f, 0f)
        chartConsumptionTemp.axisLeft.enableGridDashedLine(5f, 5f, 0f)
        //lineChart.setDrawGridBackground()
        chartConsumptionTemp.xAxis.labelCount = 11
        chartConsumptionTemp.xAxis.position = XAxis.XAxisPosition.BOTTOM
    }

    private fun setupAirQualityData(air: Float) {
        // data entry
        val phVal = 100.0f
        val yVals = ArrayList<Entry>()
        yVals.add(Entry(0f, phVal * 0, "0"))
        yVals.add(Entry(1f, phVal * 1, "1"))
        yVals.add(Entry(2f, phVal * 2, "2"))
        yVals.add(Entry(3f, phVal * 3, "3"))
        yVals.add(Entry(3f, phVal * 4, "4"))
        yVals.add(Entry(3f, phVal * 5, "5"))

        val yVal2 = ArrayList<Entry>()
        yVal2.add(Entry(0f, air * 0, "0"))
        yVal2.add(Entry(1f, air * 1, "1"))
        yVal2.add(Entry(2f, air * 2, "2"))
        yVal2.add(Entry(3f, air * 3, "3"))
        yVal2.add(Entry(3f, air * 4, "4"))
        yVal2.add(Entry(3f, air * 5, "5"))

        val set1: LineDataSet
        set1 = LineDataSet(yVals, "Threshold")

        val set2: LineDataSet
        set2 = LineDataSet(yVal2, "Actual")

        val phLeval = arrayOf("2", "4", "6", "8", "10", "12", "14")
        val time = arrayOf("20", "40", "60", "80")

        val formatter = object : ValueFormatter() {
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return time[value.toInt()]
            }
        }

        // set1.fillAlpha = 110
        // set1.setFillColor(Color.RED);

        // set the line to be drawn like this "- - - - - -"
        set1.enableDashedLine(5f, 5f, 0f);
        set1.enableDashedHighlightLine(10f, 5f, 0f);

        set1.color = Color.GREEN
        set1.setCircleColor(Color.GREEN)
        set1.lineWidth = 2f
        set1.circleRadius = 3f
        set1.setDrawCircleHole(false)
        set1.valueTextSize = 0f
        set1.setDrawFilled(false)

        val dataSets = ArrayList<ILineDataSet>()
        dataSets.add(set1)
        dataSets.add(set2)

        val data = LineData(dataSets)

        // set data
        chartConsumptionAir.setData(data)
        chartConsumptionAir.xAxis.setValueFormatter(formatter)

//        chartConsumptionPh.getAxisLeft().setAxisMaxValue(100f)
//        chartConsumptionPh.getAxisLeft().setAxisMinValue(0f)


//        chartConsumptionPh.setVisibleYRange(0f, 14f, YAxis.AxisDependency.LEFT)

        chartConsumptionAir.description.isEnabled = true
        val description = Description()
        val des = "Y Axis : Air Quality (ppm) \nX Axis : time(j)"
        description.setText(des)
        description.textSize = 18f
        description.textColor = Color.BLUE
        chartConsumptionAir.description = description


        chartConsumptionAir.legend.isEnabled = true
        chartConsumptionAir.setPinchZoom(true)
        chartConsumptionAir.xAxis.enableGridDashedLine(5f, 5f, 0f)
        chartConsumptionAir.axisRight.enableGridDashedLine(5f, 5f, 0f)
        chartConsumptionAir.axisLeft.enableGridDashedLine(5f, 5f, 0f)
        //lineChart.setDrawGridBackground()
        chartConsumptionAir.xAxis.labelCount = 11
        chartConsumptionAir.xAxis.position = XAxis.XAxisPosition.BOTTOM
    }

    private fun setupPhQualityData(ph: Float) {
        // Ph values
        // data entry
        val phVal = 4.0f
        val yVals = ArrayList<Entry>()
        yVals.add(Entry(0f, phVal * 0, "0"))
        yVals.add(Entry(1f, phVal * 1, "1"))
        yVals.add(Entry(2f, phVal * 2, "2"))
        yVals.add(Entry(3f, phVal * 3, "3"))
        yVals.add(Entry(3f, phVal * 4, "4"))
        yVals.add(Entry(3f, phVal * 5, "5"))

        val yVal2 = ArrayList<Entry>()
        yVal2.add(Entry(0f, ph * 0, "0"))
        yVal2.add(Entry(1f, ph * 1, "1"))
        yVal2.add(Entry(2f, ph * 2, "2"))
        yVal2.add(Entry(3f, ph * 3, "3"))
        yVal2.add(Entry(3f, ph * 4, "4"))
        yVal2.add(Entry(3f, ph * 5, "5"))

        val set1: LineDataSet
        set1 = LineDataSet(yVals, "Threshold")

        val set2: LineDataSet
        set2 = LineDataSet(yVal2, "Actual")

        val phLeval = arrayOf("2", "4", "6", "8", "10", "12", "14")
        val time = arrayOf("20", "40", "60", "80")

        val formatter = object : ValueFormatter() {
            override fun getAxisLabel(value: Float, axis: AxisBase?): String {
                return time[value.toInt()]
            }
        }

        // set1.fillAlpha = 110
        // set1.setFillColor(Color.RED);

        // set the line to be drawn like this "- - - - - -"
        set1.enableDashedLine(5f, 5f, 0f);
        set1.enableDashedHighlightLine(10f, 5f, 0f);

        set1.color = Color.GREEN
        set1.setCircleColor(Color.GREEN)
        set1.lineWidth = 2f
        set1.circleRadius = 3f
        set1.setDrawCircleHole(false)
        set1.valueTextSize = 0f
        set1.setDrawFilled(false)

        val dataSets = ArrayList<ILineDataSet>()
        dataSets.add(set1)
        dataSets.add(set2)

        val data = LineData(dataSets)

        // set data
        chartConsumptionPh.setData(data)
        chartConsumptionPh.xAxis.setValueFormatter(formatter)

//        chartConsumptionPh.getAxisLeft().setAxisMaxValue(100f)
//        chartConsumptionPh.getAxisLeft().setAxisMinValue(0f)


//        chartConsumptionPh.setVisibleYRange(0f, 14f, YAxis.AxisDependency.LEFT)
        chartConsumptionPh.description.isEnabled = true
        val description = Description()
        val des = "Y Axis : Ph Level \nX Axis : time(j)"
        description.setText(des)
        description.textSize = 18f
        description.textColor = Color.BLUE
        chartConsumptionPh.description = description

        chartConsumptionPh.legend.isEnabled = true

        chartConsumptionPh.setPinchZoom(true)
        chartConsumptionPh.xAxis.enableGridDashedLine(5f, 5f, 0f)
        chartConsumptionPh.axisRight.enableGridDashedLine(5f, 5f, 0f)
        chartConsumptionPh.axisLeft.enableGridDashedLine(5f, 5f, 0f)
        //lineChart.setDrawGridBackground()
        chartConsumptionPh.xAxis.labelCount = 11
        chartConsumptionPh.xAxis.position = XAxis.XAxisPosition.BOTTOM
    }

}
