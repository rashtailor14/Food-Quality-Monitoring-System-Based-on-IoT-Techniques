package com.leakhead.foodqualityapp.ui.charts.view

import com.leakhead.foodqualityapp.data.database.repository.history.FoodHistory
import com.leakhead.foodqualityapp.ui.base.view.MVPView

/**
 * Created by user on 25-February-2020
 */
interface ChartsMVPView : MVPView {

    fun displayFoodHistoryList(foodHistory: List<FoodHistory>?): Unit?

    fun displayFoodHistoryListData(foodHistory: List<String>): Unit?
}