package com.leakhead.foodqualityapp.ui.charts

import com.leakhead.foodqualityapp.ui.charts.fragments.ChartsFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

/**
 * Created by jyotidubey on 14/01/18.
 */
@Module
internal abstract class ChartsFragmentProvider {

    @ContributesAndroidInjector(modules = [ChartsFragmentModule::class])
    internal abstract fun provideChartsFragmentFactory(): ChartsFragment
}