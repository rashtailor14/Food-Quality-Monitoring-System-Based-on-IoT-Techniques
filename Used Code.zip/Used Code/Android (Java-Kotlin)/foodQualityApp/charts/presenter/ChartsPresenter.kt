package com.leakhead.foodqualityapp.ui.charts.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.BasePresenter
import com.leakhead.foodqualityapp.ui.charts.interactor.ChartsMVPInteractor
import com.leakhead.foodqualityapp.ui.charts.view.ChartsMVPView
import com.leakhead.foodqualityapp.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import org.json.JSONObject
import javax.inject.Inject

/**
 * Created by user on 25-February-2020
 */
class ChartsPresenter<V : ChartsMVPView, I : ChartsMVPInteractor> @Inject internal constructor(
    interactor: I,
    schedulerProvider: SchedulerProvider,
    disposable: CompositeDisposable
) : BasePresenter<V, I>(
    interactor = interactor,
    schedulerProvider = schedulerProvider,
    compositeDisposable = disposable
),
    ChartsMVPPresenter<V, I> {

    override fun onViewPrepared() {
        getView()?.showProgress()
        interactor?.let {
            it.getFoodHistoryList()
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe { foodResponse ->
                    getView()?.let {
                        it.hideProgress()
                        it.displayFoodHistoryList(foodResponse.data)
                    }
                }
        }
    }

    override fun onViewPreparedHistory(jsonObject: JSONObject) {
        getView()?.showProgress()
        interactor?.let {
            it.getFoodHistoryDataList(jsonObject)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe { foodResponse ->
                    getView()?.let {
                        it.hideProgress()
                        it.displayFoodHistoryListData(foodResponse.processMessage.toList())
                    }
                }
        }
    }

}