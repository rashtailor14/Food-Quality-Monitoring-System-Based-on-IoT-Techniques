package com.leakhead.foodqualityapp.ui.charts.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.MVPPresenter
import com.leakhead.foodqualityapp.ui.charts.interactor.ChartsMVPInteractor
import com.leakhead.foodqualityapp.ui.charts.view.ChartsMVPView
import org.json.JSONObject

/**
 * Created by user on 25-February-2020
 */

interface ChartsMVPPresenter<V : ChartsMVPView, I : ChartsMVPInteractor> : MVPPresenter<V, I> {

    fun onViewPrepared()

    fun onViewPreparedHistory(jsonObject: JSONObject)
}