package com.leakhead.foodqualityapp.ui.charts.adapter

import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.ui.charts.view.ChartDescriptionActivity
import com.leakhead.foodqualityapp.ui.graph.GraphHourlyActivity
import com.leakhead.foodqualityapp.ui.graph.GraphRealtimeActivity
import kotlinx.android.synthetic.main.items_charts_food_list.view.*

/**
 * Created by user on 25-February-2020
 */
class ChartsHistoryListAdapter(private val blogListItems: MutableList<String>) :
    RecyclerView.Adapter<ChartsHistoryListAdapter.ChartsHistoryViewHolder>() {

    override fun getItemCount() = this.blogListItems.size

    override fun onBindViewHolder(holder: ChartsHistoryViewHolder, position: Int) = holder.let {
        it.clear()
        it.onBind(position)
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int) = ChartsHistoryViewHolder(
        LayoutInflater.from(parent?.context)
            .inflate(R.layout.items_charts_food_list, parent, false)
    )

    internal fun addFoodHistoryToList(foodHistory: List<String>) {
        this.blogListItems.addAll(foodHistory)
        notifyDataSetChanged()
    }

    inner class ChartsHistoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun clear() {
            itemView.test_id_title.text = ""
            itemView.test_id.text = ""
        }

        fun onBind(position: Int) {

            blogListItems[position]

            inflateData("Food Name / Test Id : ", blogListItems[position])
            setItemClickListener(blogListItems[position])


            itemView.btn_hours.setOnClickListener {
                val intent = Intent(it.context, GraphHourlyActivity::class.java)
                intent.putExtra("testId", blogListItems[position])
                it.context.startActivity(intent)
            }

            itemView.btn_realtime.setOnClickListener {
                val intent = Intent(it.context, GraphRealtimeActivity::class.java)
                intent.putExtra("testId", blogListItems[position])
                it.context.startActivity(intent)
            }


        }

        private fun setItemClickListener(testId: String?) {
            itemView.setOnClickListener {
                val intent = Intent(it.context, ChartDescriptionActivity::class.java)
                intent.putExtra("testId", testId)
                it.context.startActivity(intent)
            }
        }

        private fun inflateData(
            name: String?,
            type: String?
        ) {
            name?.let { itemView.test_id_title.text = it }
            type?.let { itemView.test_id.text = it }

        }

    }
}