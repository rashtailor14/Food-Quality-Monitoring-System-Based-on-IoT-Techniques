package com.leakhead.foodqualityapp.ui.charts.interactor

import com.leakhead.foodqualityapp.data.network.ApiHelper
import com.leakhead.foodqualityapp.data.preferences.PreferenceHelper
import com.leakhead.foodqualityapp.ui.base.interactor.BaseInteractor
import org.json.JSONObject
import javax.inject.Inject

/**
 * Created by user on 25-February-2020
 */
class ChartsInteractor @Inject internal constructor(preferenceHelper: PreferenceHelper, apiHelper: ApiHelper) :
    BaseInteractor(preferenceHelper, apiHelper),
    ChartsMVPInteractor {

    override fun demo() {

    }

    override fun getFoodHistoryList() = apiHelper.getFoodApiCall()

    override fun getFoodHistoryDataList(jsonObject: JSONObject) = apiHelper.getFoodHistoryApiCall(jsonObject)

}