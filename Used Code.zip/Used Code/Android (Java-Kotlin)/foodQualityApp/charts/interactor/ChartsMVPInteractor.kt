package com.leakhead.foodqualityapp.ui.charts.interactor

import com.leakhead.foodqualityapp.data.network.FoodHistoryResponse
import com.leakhead.foodqualityapp.data.network.FoodResponse
import com.leakhead.foodqualityapp.ui.base.interactor.MVPInteractor
import io.reactivex.Observable
import org.json.JSONObject

/**
 * Created by user on 25-February-2020
 */
interface ChartsMVPInteractor : MVPInteractor {

    fun demo()

    fun getFoodHistoryList(): Observable<FoodResponse>

    fun getFoodHistoryDataList(jsonObject: JSONObject): Observable<FoodHistoryResponse>
}