package com.leakhead.foodqualityapp.ui.charts

import com.leakhead.foodqualityapp.ui.charts.interactor.ChartsInteractor
import com.leakhead.foodqualityapp.ui.charts.interactor.ChartsMVPInteractor
import com.leakhead.foodqualityapp.ui.charts.presenter.ChartsMVPPresenter
import com.leakhead.foodqualityapp.ui.charts.presenter.ChartsPresenter
import com.leakhead.foodqualityapp.ui.charts.view.ChartsMVPView
import dagger.Module
import dagger.Provides

/**
 * Created by user on 25-February-2020
 */
@Module
class ChartsActivityModule {

    @Provides
    internal fun provideChartsInteractor(interactor: ChartsInteractor): ChartsMVPInteractor = interactor

    @Provides
    internal fun provideChartsPresenter(presenter: ChartsPresenter<ChartsMVPView, ChartsMVPInteractor>)
            : ChartsMVPPresenter<ChartsMVPView, ChartsMVPInteractor> = presenter
}