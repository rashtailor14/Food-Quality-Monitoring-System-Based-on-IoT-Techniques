package com.leakhead.foodqualityapp.service.mqtt;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttMessage;

/**
 * Created by dpnkr on 01-October-2019
 */
public class MqttMessageService extends Service {

    private static final String TAG = "MqttMessageService";
    private PahoMqttClient pahoMqttClient;
    private MqttAndroidClient mqttAndroidClient;

    String ipAddr;
    String MQTT_BROKER_URL;

    public MqttMessageService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");

        String MQTT_BROKER_URL = "tcp://192.168.0.123:1883";

        pahoMqttClient = new PahoMqttClient();
        mqttAndroidClient = pahoMqttClient.getMqttClient(getApplicationContext(), MQTT_BROKER_URL, "abcd");

        mqttAndroidClient.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
//                nh.createNotification("Your connected device is:", s);
                Log.d("dpnkrlog", "connectComplete: " + s);
            }

            @Override
            public void connectionLost(Throwable throwable) {
//                nh.createNotification("MQTT ERROR", "Device connection lost.");
                Log.d("dpnkrlog", "connectionLost: ");

            }

            @Override
            public void messageArrived(String s, MqttMessage mqttMessage) throws Exception {
                if (s.equals("leftCount")) {
                    Log.d("kkskasa", "messageArrived: left" + new String(mqttMessage.getPayload()));
//                    temp.setText(new String(message.getPayload()));
                } else if (s.equals("rightCount")) {
                    Log.d("kkskasa", "messageArrived: right" + new String(mqttMessage.getPayload()));
//                    foo.setText(new String(message.getPayload()));
                }
//                Toast.makeText(MqttMessageService.this, new String(mqttMessage.getPayload()), Toast.LENGTH_SHORT).show();
                Log.d("dpnkrlog", "messageArrived: " + new String(mqttMessage.getPayload()));

                // Old notifications
//                setMessageNotification(s, new String(mqttMessage.getPayload()));
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand");
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
    }

}
