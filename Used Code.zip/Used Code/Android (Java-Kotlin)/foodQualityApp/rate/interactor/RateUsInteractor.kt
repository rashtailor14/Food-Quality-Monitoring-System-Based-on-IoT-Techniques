package com.leakhead.foodqualityapp.ui.rate.interactor

import com.leakhead.foodqualityapp.data.network.ApiHelper
import com.leakhead.foodqualityapp.data.preferences.PreferenceHelper
import com.leakhead.foodqualityapp.ui.base.interactor.BaseInteractor
import javax.inject.Inject

/**
 * Created by jyotidubey on 15/01/18.
 */
class RateUsInteractor @Inject internal constructor(apiHelper: ApiHelper, preferenceHelper: PreferenceHelper) : BaseInteractor(apiHelper = apiHelper, preferenceHelper = preferenceHelper), RateUsMVPInterator {

    override fun submitRating() {}
}