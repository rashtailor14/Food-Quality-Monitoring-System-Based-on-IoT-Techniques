package com.leakhead.foodqualityapp.ui.rate.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.MVPPresenter
import com.leakhead.foodqualityapp.ui.rate.interactor.RateUsMVPInterator
import com.leakhead.foodqualityapp.ui.rate.view.RateUsDialogMVPView

/**
 * Created by jyotidubey on 15/01/18.
 */
interface RateUsMVPPresenter<V : RateUsDialogMVPView, I : RateUsMVPInterator> : MVPPresenter<V, I> {

    fun onLaterOptionClicked() : Unit?
    fun onSubmitOptionClicked() : Unit?
}