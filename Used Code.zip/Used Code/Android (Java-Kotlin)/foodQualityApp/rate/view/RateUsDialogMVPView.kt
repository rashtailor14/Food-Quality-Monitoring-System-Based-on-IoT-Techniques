package com.leakhead.foodqualityapp.ui.rate.view

import com.leakhead.foodqualityapp.ui.base.view.MVPView

/**
 * Created by jyotidubey on 14/01/18.
 */
interface RateUsDialogMVPView : MVPView{

    fun dismissDialog()
    fun showRatingSubmissionSuccessMessage()
}