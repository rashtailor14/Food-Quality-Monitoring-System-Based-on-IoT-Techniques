package com.leakhead.foodqualityapp.ui.hardware.sensor

import com.leakhead.foodqualityapp.ui.hardware.sensor.view.SensorFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

/**
 * Created by jyotidubey on 14/01/18.
 */
@Module
internal abstract class SensorFragmentProvider {

    @ContributesAndroidInjector(modules = [SensorFragmentModule::class])
    internal abstract fun provideSensorFragmentFactory(): SensorFragment
}