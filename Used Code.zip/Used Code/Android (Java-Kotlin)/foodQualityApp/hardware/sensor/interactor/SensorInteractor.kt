package com.leakhead.foodqualityapp.ui.hardware.sensor.interactor

import com.leakhead.foodqualityapp.data.network.ApiHelper
import com.leakhead.foodqualityapp.data.preferences.PreferenceHelper
import com.leakhead.foodqualityapp.ui.base.interactor.BaseInteractor
import javax.inject.Inject

/**
 * Created by jyotidubey on 13/01/18.
 */
class SensorInteractor @Inject internal constructor(preferenceHelper: PreferenceHelper, apiHelper: ApiHelper) : BaseInteractor(preferenceHelper, apiHelper), SensorMVPInteractor {

    override fun getSensorList() = apiHelper.getSensorApiCall()

}