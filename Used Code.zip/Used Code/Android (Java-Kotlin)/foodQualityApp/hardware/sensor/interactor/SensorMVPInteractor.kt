package com.leakhead.foodqualityapp.ui.hardware.sensor.interactor

import com.leakhead.foodqualityapp.data.network.SensorResponse
import com.leakhead.foodqualityapp.ui.base.interactor.MVPInteractor
import io.reactivex.Observable

/**
 * Created by jyotidubey on 13/01/18.
 */
interface SensorMVPInteractor : MVPInteractor {

    fun getSensorList(): Observable<SensorResponse>

}