package com.leakhead.foodqualityapp.ui.hardware.sensor.view

import android.content.Intent
import android.net.Uri
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.data.database.repository.sensor.Sensor
import kotlinx.android.synthetic.main.item_blog_list.view.contentTextView
import kotlinx.android.synthetic.main.item_sensor_list.view.*

class SensorAdapter(private val sensorListItems: MutableList<Sensor>) :
    RecyclerView.Adapter<SensorAdapter.SensorViewHolder>() {

    override fun getItemCount() = this.sensorListItems.size

    override fun onBindViewHolder(holder: SensorViewHolder, position: Int) = holder.let {
        it.clear()
        it.onBind(position)
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int) = SensorViewHolder(
        LayoutInflater.from(parent?.context)
            .inflate(R.layout.item_sensor_list, parent, false)
    )

    internal fun addSensorsToList(sensors: List<Sensor>) {
        this.sensorListItems.addAll(sensors)
        notifyDataSetChanged()
    }

    inner class SensorViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun clear() {
            itemView.tv_sensorName.text = ""
            itemView.modelTextView.text = ""
            itemView.tv_sensorType.text = ""
            itemView.tv_sensorDate.text = ""
            itemView.contentTextView.text = ""
        }

        fun onBind(position: Int) {

            val (id, sensorId, name, type, category, model, maker, details, date) = sensorListItems[position]

            inflateData(name, model, type, date, details)
//            setItemClickListener(blogUrl)
        }

        private fun setItemClickListener(blogUrl: String?) {
            itemView.setOnClickListener {
                blogUrl?.let {
                    try {
                        val intent = Intent()
                        // using "with" as an example
                        with(intent) {
                            action = Intent.ACTION_VIEW
                            data = Uri.parse(it)
                            addCategory(Intent.CATEGORY_BROWSABLE)
                        }
                        itemView.context.startActivity(intent)
                    } catch (e: Exception) {
                    }
                }

            }
        }

        private fun inflateData(
            name: String?,
            model: String?,
            type: String?,
            date: String?,
            description: String?
        ) {
            name?.let { itemView.tv_sensorName.text = it }
            model?.let { itemView.modelTextView.text = it }
            type?.let { itemView.tv_sensorType.text = it }
            date?.let { itemView.tv_sensorDate.text = it }
            description?.let { itemView.contentTextView.text = it }
        }

    }
}
