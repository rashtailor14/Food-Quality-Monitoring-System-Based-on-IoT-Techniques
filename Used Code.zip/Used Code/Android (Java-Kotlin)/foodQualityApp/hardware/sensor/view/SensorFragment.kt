package com.leakhead.foodqualityapp.ui.hardware.sensor.view

import android.os.Bundle
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.data.database.repository.sensor.Sensor
import com.leakhead.foodqualityapp.ui.base.view.BaseFragment
import com.leakhead.foodqualityapp.ui.hardware.sensor.interactor.SensorMVPInteractor
import com.leakhead.foodqualityapp.ui.hardware.sensor.presenter.SensorMVPPresenter
import kotlinx.android.synthetic.main.fragment_sensor.*
import javax.inject.Inject


/**
 * Created by jyotidubey on 13/01/18.
 */
class SensorFragment : BaseFragment(), SensorMVPView {

    companion object {

        fun newInstance(): SensorFragment {
            return SensorFragment()
        }
    }

    @Inject
    internal lateinit var sensorAdapter: SensorAdapter
    @Inject
    internal lateinit var layoutManager: LinearLayoutManager
    @Inject
    internal lateinit var presenter: SensorMVPPresenter<SensorMVPView, SensorMVPInteractor>


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) =
        inflater.inflate(R.layout.fragment_sensor, container, false)


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        presenter.onAttach(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun setUp() {
        layoutManager.orientation = LinearLayoutManager.VERTICAL
        sensor_recycler_view.layoutManager = layoutManager
        sensor_recycler_view.itemAnimator = DefaultItemAnimator()
        sensor_recycler_view.adapter = sensorAdapter
        presenter.onViewPrepared()
    }

    override fun displaySensorList(sensors: List<Sensor>?) = sensors?.let {
        sensorAdapter.addSensorsToList(it)
    }

    override fun onDestroyView() {
        presenter.onDetach()
        super.onDestroyView()
    }
}