package com.leakhead.foodqualityapp.ui.hardware.sensor.view

import com.leakhead.foodqualityapp.data.database.repository.sensor.Sensor
import com.leakhead.foodqualityapp.ui.base.view.MVPView

/**
 * Created by jyotidubey on 13/01/18.
 */
interface SensorMVPView : MVPView {

    fun displaySensorList(sensors: List<Sensor>?): Unit?

}