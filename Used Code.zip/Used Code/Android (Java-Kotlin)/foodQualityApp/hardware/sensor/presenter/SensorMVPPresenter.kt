package com.leakhead.foodqualityapp.ui.hardware.sensor.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.MVPPresenter
import com.leakhead.foodqualityapp.ui.hardware.sensor.interactor.SensorMVPInteractor
import com.leakhead.foodqualityapp.ui.hardware.sensor.view.SensorMVPView

/**
 * Created by jyotidubey on 13/01/18.
 */
interface SensorMVPPresenter<V : SensorMVPView, I : SensorMVPInteractor> : MVPPresenter<V, I> {

    fun onViewPrepared()
}