package com.leakhead.foodqualityapp.ui.hardware.sensor.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.BasePresenter
import com.leakhead.foodqualityapp.ui.hardware.sensor.interactor.SensorMVPInteractor
import com.leakhead.foodqualityapp.ui.hardware.sensor.view.SensorMVPView
import com.leakhead.foodqualityapp.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

/**
 * Created by jyotidubey on 13/01/18.
 */
class SensorPresenter<V : SensorMVPView, I : SensorMVPInteractor> @Inject constructor(
    interactor: I,
    schedulerProvider: SchedulerProvider,
    compositeDisposable: CompositeDisposable
) : BasePresenter<V, I>(
    interactor = interactor,
    schedulerProvider = schedulerProvider,
    compositeDisposable = compositeDisposable
), SensorMVPPresenter<V, I> {

    override fun onViewPrepared() {
        getView()?.showProgress()
        interactor?.let {
            it.getSensorList()
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe { blogResponse ->
                    getView()?.let {
                        it.hideProgress()
                        it.displaySensorList(blogResponse.data)
                    }
                }
        }
    }
}