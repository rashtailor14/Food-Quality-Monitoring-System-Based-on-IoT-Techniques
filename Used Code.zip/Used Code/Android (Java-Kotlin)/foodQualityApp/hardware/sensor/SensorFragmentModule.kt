package com.leakhead.foodqualityapp.ui.hardware.sensor

import android.support.v7.widget.LinearLayoutManager
import com.leakhead.foodqualityapp.ui.hardware.sensor.interactor.SensorInteractor
import com.leakhead.foodqualityapp.ui.hardware.sensor.interactor.SensorMVPInteractor
import com.leakhead.foodqualityapp.ui.hardware.sensor.presenter.SensorMVPPresenter
import com.leakhead.foodqualityapp.ui.hardware.sensor.presenter.SensorPresenter
import com.leakhead.foodqualityapp.ui.hardware.sensor.view.SensorAdapter
import com.leakhead.foodqualityapp.ui.hardware.sensor.view.SensorFragment
import com.leakhead.foodqualityapp.ui.hardware.sensor.view.SensorMVPView
import dagger.Module
import dagger.Provides
import java.util.*

/**
 * Created by jyotidubey on 14/01/18.
 */
@Module
class SensorFragmentModule {

    @Provides
    internal fun provideBlogInteractor(interactor: SensorInteractor): SensorMVPInteractor = interactor

    @Provides
    internal fun provideBlogPresenter(presenter: SensorPresenter<SensorMVPView, SensorMVPInteractor>)
            : SensorMVPPresenter<SensorMVPView, SensorMVPInteractor> = presenter

    @Provides
    internal fun provideBlogAdapter(): SensorAdapter = SensorAdapter(ArrayList())

    @Provides
    internal fun provideLinearLayoutManager(fragment: SensorFragment): LinearLayoutManager =
        LinearLayoutManager(fragment.activity)

}