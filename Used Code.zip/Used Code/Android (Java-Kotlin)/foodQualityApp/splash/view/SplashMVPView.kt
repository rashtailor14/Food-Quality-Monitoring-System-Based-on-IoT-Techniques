package com.leakhead.foodqualityapp.ui.splash.view

import com.leakhead.foodqualityapp.ui.base.view.MVPView

/**
 * Created by jyotidubey on 04/01/18.
 */
interface SplashMVPView : MVPView {

    fun showSuccessToast()
    fun showErrorToast()
    fun openMainActivity()
    fun openLoginActivity()
}