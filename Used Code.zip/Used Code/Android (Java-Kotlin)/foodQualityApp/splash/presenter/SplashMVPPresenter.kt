package com.leakhead.foodqualityapp.ui.splash.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.MVPPresenter
import com.leakhead.foodqualityapp.ui.splash.interactor.SplashMVPInteractor
import com.leakhead.foodqualityapp.ui.splash.view.SplashMVPView

/**
 * Created by jyotidubey on 04/01/18.
 */
interface SplashMVPPresenter<V : SplashMVPView, I : SplashMVPInteractor> : MVPPresenter<V,I>