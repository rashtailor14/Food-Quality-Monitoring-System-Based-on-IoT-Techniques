package com.leakhead.foodqualityapp.ui.splash.interactor

import android.content.Context
import com.google.gson.GsonBuilder
import com.google.gson.internal.`$Gson$Types`
import com.leakhead.foodqualityapp.data.database.repository.device.Device
import com.leakhead.foodqualityapp.data.database.repository.device.DeviceRepo
import com.leakhead.foodqualityapp.data.database.repository.food.Food
import com.leakhead.foodqualityapp.data.database.repository.food.FoodRepo
import com.leakhead.foodqualityapp.data.database.repository.history.FoodHistory
import com.leakhead.foodqualityapp.data.database.repository.history.FoodHistoryRepo
import com.leakhead.foodqualityapp.data.database.repository.options.Options
import com.leakhead.foodqualityapp.data.database.repository.options.OptionsRepo
import com.leakhead.foodqualityapp.data.database.repository.questions.Question
import com.leakhead.foodqualityapp.data.database.repository.questions.QuestionRepo
import com.leakhead.foodqualityapp.data.database.repository.sensor.Sensor
import com.leakhead.foodqualityapp.data.database.repository.sensor.SensorRepo
import com.leakhead.foodqualityapp.data.database.repository.user.User
import com.leakhead.foodqualityapp.data.database.repository.user.UserRepo
import com.leakhead.foodqualityapp.data.network.ApiHelper
import com.leakhead.foodqualityapp.data.preferences.PreferenceHelper
import com.leakhead.foodqualityapp.ui.base.interactor.BaseInteractor
import com.leakhead.foodqualityapp.util.AppConstants
import com.leakhead.foodqualityapp.util.FileUtils
import io.reactivex.Observable
import javax.inject.Inject

/**
 * Created by jyotidubey on 04/01/18.
 */
class SplashInteractor @Inject constructor(
        private val mContext: Context,
        private val questionRepoHelper: QuestionRepo,
        private val deviceRepo: DeviceRepo,
        private val foodRepo: FoodRepo,
        private val historyRepo: FoodHistoryRepo,
        private val sensorRepo: SensorRepo,
        private val userRepo: UserRepo,
        private val optionsRepoHelper: OptionsRepo,
        preferenceHelper: PreferenceHelper,
        apiHelper: ApiHelper
) : BaseInteractor(preferenceHelper, apiHelper), SplashMVPInteractor {

    override fun getQuestion(): Observable<List<Question>> {
        return questionRepoHelper.loadQuestions()
    }

    override fun seedQuestions(): Observable<Boolean> {
        val builder = GsonBuilder().excludeFieldsWithoutExposeAnnotation()
        val gson = builder.create()
        return questionRepoHelper.isQuestionsRepoEmpty().concatMap { isEmpty ->
            if (isEmpty) {
                val type = `$Gson$Types`.newParameterizedTypeWithOwner(null, List::class.java, Question::class.java)
                val questionList = gson.fromJson<List<Question>>(
                        FileUtils.loadJSONFromAsset(
                                mContext,
                                AppConstants.SEED_DATABASE_QUESTIONS),
                        type)
                questionRepoHelper.insertQuestions(questionList)
            } else
                Observable.just(false)
        }
    }

    override fun seedOptions(): Observable<Boolean> {
        val builder = GsonBuilder().excludeFieldsWithoutExposeAnnotation()
        val gson = builder.create()
        return optionsRepoHelper.isOptionsRepoEmpty().concatMap { isEmpty ->
            if (isEmpty) {
                val type = `$Gson$Types`.newParameterizedTypeWithOwner(null, List::class.java, Options::class.java)
                val optionsList = gson.fromJson<List<Options>>(
                        FileUtils.loadJSONFromAsset(
                                mContext,
                                AppConstants.SEED_DATABASE_OPTIONS),
                        type)
                optionsRepoHelper.insertOptions(optionsList)
            } else
                Observable.just(false)
        }
    }

    override fun seedDevice(): Observable<Boolean> {
        val builder = GsonBuilder().excludeFieldsWithoutExposeAnnotation()
        val gson = builder.create()
        return deviceRepo.isDeviceRepoEmpty().concatMap { isEmpty ->
            if (isEmpty) {
                val type = `$Gson$Types`.newParameterizedTypeWithOwner(null, List::class.java, Device::class.java)
                val optionsList = gson.fromJson<List<Device>>(
                        FileUtils.loadJSONFromAsset(
                                mContext,
                                AppConstants.SEED_DATABASE_DEVICE),
                        type)
                deviceRepo.insertDevice(optionsList)
            } else
                Observable.just(false)
        }
    }

    override fun seedFood(): Observable<Boolean> {
        val builder = GsonBuilder().excludeFieldsWithoutExposeAnnotation()
        val gson = builder.create()
        return foodRepo.isFoodRepoEmpty().concatMap { isEmpty ->
            if (isEmpty) {
                val type = `$Gson$Types`.newParameterizedTypeWithOwner(null, List::class.java, Food::class.java)
                val optionsList = gson.fromJson<List<Food>>(
                        FileUtils.loadJSONFromAsset(
                                mContext,
                                AppConstants.SEED_DATABASE_FOOD),
                        type)
                foodRepo.insertFood(optionsList)
            } else
                Observable.just(false)
        }
    }

    override fun seedFoodHistory(): Observable<Boolean> {
        val builder = GsonBuilder().excludeFieldsWithoutExposeAnnotation()
        val gson = builder.create()
        return historyRepo.isFoodRepoEmpty().concatMap { isEmpty ->
            if (isEmpty) {
                val type = `$Gson$Types`.newParameterizedTypeWithOwner(null, List::class.java, FoodHistory::class.java)
                val optionsList = gson.fromJson<List<FoodHistory>>(
                        FileUtils.loadJSONFromAsset(
                                mContext,
                                AppConstants.SEED_DATABASE_FOOD_HISTORY),
                        type)
                historyRepo.insertFoodHistory(optionsList)
            } else
                Observable.just(false)
        }
    }

    override fun seedSensor(): Observable<Boolean> {
        val builder = GsonBuilder().excludeFieldsWithoutExposeAnnotation()
        val gson = builder.create()
        return sensorRepo.isSensorRepoEmpty().concatMap { isEmpty ->
            if (isEmpty) {
                val type = `$Gson$Types`.newParameterizedTypeWithOwner(null, List::class.java, Sensor::class.java)
                val optionsList = gson.fromJson<List<Sensor>>(
                        FileUtils.loadJSONFromAsset(
                                mContext,
                                AppConstants.SEED_DATABASE_SENSOR),
                        type)
                sensorRepo.insertSensor(optionsList)
            } else
                Observable.just(false)
        }
    }

    override fun seedUser(): Observable<Boolean> {
        val builder = GsonBuilder().excludeFieldsWithoutExposeAnnotation()
        val gson = builder.create()
        return userRepo.isUserRepoEmpty().concatMap { isEmpty ->
            if (isEmpty) {
                val type = `$Gson$Types`.newParameterizedTypeWithOwner(null, List::class.java, User::class.java)
                val optionsList = gson.fromJson<List<User>>(
                        FileUtils.loadJSONFromAsset(
                                mContext,
                                AppConstants.SEED_DATABASE_USER),
                        type)
                userRepo.insertUser(optionsList)
            } else
                Observable.just(false)
        }
    }
}