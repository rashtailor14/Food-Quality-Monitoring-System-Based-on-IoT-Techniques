package com.leakhead.foodqualityapp.ui.feed.blog.interactor

import com.leakhead.foodqualityapp.data.network.BlogResponse
import com.leakhead.foodqualityapp.ui.base.interactor.MVPInteractor
import io.reactivex.Observable

/**
 * Created by jyotidubey on 13/01/18.
 */
interface BlogMVPInteractor : MVPInteractor {

    fun getBlogList(): Observable<BlogResponse>

}