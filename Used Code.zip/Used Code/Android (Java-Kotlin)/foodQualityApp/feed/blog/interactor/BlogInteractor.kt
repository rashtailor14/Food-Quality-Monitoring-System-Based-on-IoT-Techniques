package com.leakhead.foodqualityapp.ui.feed.blog.interactor

import com.leakhead.foodqualityapp.data.network.ApiHelper
import com.leakhead.foodqualityapp.data.preferences.PreferenceHelper
import com.leakhead.foodqualityapp.ui.base.interactor.BaseInteractor
import javax.inject.Inject

/**
 * Created by jyotidubey on 13/01/18.
 */
class BlogInteractor @Inject internal constructor(preferenceHelper: PreferenceHelper, apiHelper: ApiHelper) : BaseInteractor(preferenceHelper, apiHelper), BlogMVPInteractor {

    override fun getBlogList() = apiHelper.getBlogApiCall()

}