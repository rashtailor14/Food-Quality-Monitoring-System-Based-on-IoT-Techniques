package com.leakhead.foodqualityapp.ui.feed.blog.view

import com.leakhead.foodqualityapp.data.network.Blog
import com.leakhead.foodqualityapp.ui.base.view.MVPView

/**
 * Created by jyotidubey on 13/01/18.
 */
interface BlogMVPView : MVPView {

    fun displayBlogList(blogs: List<Blog>?) : Unit?

}