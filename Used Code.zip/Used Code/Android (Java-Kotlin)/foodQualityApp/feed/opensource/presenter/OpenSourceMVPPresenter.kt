package com.leakhead.foodqualityapp.ui.feed.opensource.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.MVPPresenter
import com.leakhead.foodqualityapp.ui.feed.opensource.interactor.OpenSourceMVPInteractor
import com.leakhead.foodqualityapp.ui.feed.opensource.view.OpenSourceMVPView

/**
 * Created by jyotidubey on 14/01/18.
 */
interface OpenSourceMVPPresenter<V : OpenSourceMVPView, I : OpenSourceMVPInteractor> : MVPPresenter<V, I> {

    fun onViewPrepared()
}