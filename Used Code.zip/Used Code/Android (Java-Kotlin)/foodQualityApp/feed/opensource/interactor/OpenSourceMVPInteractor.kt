package com.leakhead.foodqualityapp.ui.feed.opensource.interactor

import com.leakhead.foodqualityapp.data.network.OpenSourceResponse
import com.leakhead.foodqualityapp.ui.base.interactor.MVPInteractor
import io.reactivex.Observable

/**
 * Created by jyotidubey on 14/01/18.
 */
interface OpenSourceMVPInteractor : MVPInteractor {

    fun getOpenSourceList(): Observable<OpenSourceResponse>
}