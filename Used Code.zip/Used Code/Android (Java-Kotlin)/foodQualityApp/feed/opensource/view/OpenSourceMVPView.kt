package com.leakhead.foodqualityapp.ui.feed.opensource.view

import com.leakhead.foodqualityapp.data.network.OpenSource
import com.leakhead.foodqualityapp.ui.base.view.MVPView

/**
 * Created by jyotidubey on 14/01/18.
 */
interface OpenSourceMVPView : MVPView {
    fun displayOpenSourceList(blogs: List<OpenSource>?)

}