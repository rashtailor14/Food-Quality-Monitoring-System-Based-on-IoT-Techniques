package com.leakhead.foodqualityapp.ui.main.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.BasePresenter
import com.leakhead.foodqualityapp.ui.main.interactor.MainMVPInteractor
import com.leakhead.foodqualityapp.ui.main.view.MainMVPView
import com.leakhead.foodqualityapp.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

/**
 * Created by jyotidubey on 08/01/18.
 */
class MainPresenter<V : MainMVPView, I : MainMVPInteractor> @Inject internal constructor(interactor: I, schedulerProvider: SchedulerProvider, disposable: CompositeDisposable) : BasePresenter<V, I>(interactor = interactor, schedulerProvider = schedulerProvider, compositeDisposable = disposable), MainMVPPresenter<V, I> {

    override fun onAttach(view: V?) {
        super.onAttach(view)
//        getUserData()
//        getQuestionCards()
    }


    override fun onDrawerOptionLogoutClick() {
        getView()?.showProgress()
        interactor?.let {
            compositeDisposable.add(
                    it.makeLogoutApiCall()
                            .compose(schedulerProvider.ioToMainObservableScheduler())
                            .subscribe({
                                interactor?.performUserLogout()
                                getView()?.let {
                                    it.hideProgress()
                                    it.openLoginActivity()
                                }
                            }, { err -> println(err) }))
        }

    }






}