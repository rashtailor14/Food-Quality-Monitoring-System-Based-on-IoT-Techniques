package com.leakhead.foodqualityapp.ui.main.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.MVPPresenter
import com.leakhead.foodqualityapp.ui.main.interactor.MainMVPInteractor
import com.leakhead.foodqualityapp.ui.main.view.MainMVPView

/**
 * Created by jyotidubey on 08/01/18.
 */
interface MainMVPPresenter<V : MainMVPView, I : MainMVPInteractor> : MVPPresenter<V, I> {

//    fun refreshQuestionCards(): Boolean?
//    fun onDrawerOptionAboutClick() : Unit?
//    fun onDrawerOptionRateUsClick(): Unit?
//    fun onDrawerOptionFeedClick(): Unit?
    fun onDrawerOptionLogoutClick()

}