package com.leakhead.foodqualityapp.ui.main.view

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.ui.GlobalValues
import com.leakhead.foodqualityapp.ui.about.view.AboutFragment
import com.leakhead.foodqualityapp.ui.base.view.BaseActivity
import com.leakhead.foodqualityapp.ui.charts.view.ChartsActivity
import com.leakhead.foodqualityapp.ui.checker.view.FoodCheckerActivity
import com.leakhead.foodqualityapp.ui.device.view.DeviceMVPActivity
import com.leakhead.foodqualityapp.ui.feed.view.FeedActivity
import com.leakhead.foodqualityapp.ui.food.view.FoodActivity
import com.leakhead.foodqualityapp.ui.hardware.view.HardwareActivity
import com.leakhead.foodqualityapp.ui.login.view.LoginActivity
import com.leakhead.foodqualityapp.ui.main.interactor.MainMVPInteractor
import com.leakhead.foodqualityapp.ui.main.presenter.MainMVPPresenter
import com.leakhead.foodqualityapp.ui.user.view.UserMVPActivity
import com.leakhead.foodqualityapp.util.extension.removeFragment
import dagger.android.DispatchingAndroidInjector
import dagger.android.support.HasSupportFragmentInjector
import kotlinx.android.synthetic.main.activity_main.*
import javax.inject.Inject

class MainActivity : BaseActivity(), MainMVPView,
    HasSupportFragmentInjector {

    @Inject
    internal lateinit var presenter: MainMVPPresenter<MainMVPView, MainMVPInteractor>
    @Inject
    internal lateinit var fragmentDispatchingAndroidInjector: DispatchingAndroidInjector<Fragment>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        presenter.onAttach(this)

        textBtnLogout.setOnClickListener {
            presenter.onDrawerOptionLogoutClick()
        }

        lin_foodHistory.setOnClickListener {
            val intent = Intent(this, FoodActivity::class.java)
            startActivity(intent)
        }

        lin_sensor.setOnClickListener {
            val intent = Intent(this, HardwareActivity::class.java)
            startActivity(intent)
        }

        lin_analytics.setOnClickListener {
            val intent = Intent(this, ChartsActivity::class.java)
            startActivity(intent)
        }

        lin_foodChecker.setOnClickListener {
            val intent = Intent(this, FoodCheckerActivity::class.java)
            startActivity(intent)
        }

        lin_deviceInfo.setOnClickListener {
            val intent = Intent(this, DeviceMVPActivity::class.java)
            startActivity(intent)
        }

        lin_userProfile.setOnClickListener {
            val intent = Intent(this, UserMVPActivity::class.java)
            startActivity(intent)
        }

        GlobalValues.globalFoodName = null
        GlobalValues.globalFoodType = null
        GlobalValues.currentId = null
    }

    override fun onResume() {
        super.onResume()

        GlobalValues.globalFoodName = null
        GlobalValues.globalFoodType = null
        GlobalValues.currentId = null
    }

    override fun onBackPressed() {
        val fragment = supportFragmentManager.findFragmentByTag(AboutFragment.TAG)
        fragment?.let { onFragmentDetached(AboutFragment.TAG) } ?: super.onBackPressed()
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    override fun onFragmentDetached(tag: String) {
        supportFragmentManager?.removeFragment(tag = tag)
    }

    override fun onFragmentAttached() {
    }


    override fun openLoginActivity() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }

//    override fun openAboutFragment() {
//        lockDrawer()
//        supportFragmentManager.addFragment(R.id.cl_root_view, AboutFragment.newInstance(), AboutFragment.TAG)
//    }

    override fun openFeedActivity() {
        val intent = Intent(this, FeedActivity::class.java)
        startActivity(intent)
    }


    override fun supportFragmentInjector() = fragmentDispatchingAndroidInjector
}
