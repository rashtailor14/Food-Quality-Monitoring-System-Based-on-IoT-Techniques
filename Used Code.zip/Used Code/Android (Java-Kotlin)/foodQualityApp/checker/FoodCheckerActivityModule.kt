package com.leakhead.foodqualityapp.ui.checker

import com.leakhead.foodqualityapp.ui.checker.interactor.FoodCheckerMVPInteractor
import com.leakhead.foodqualityapp.ui.checker.presenter.FoodCheckerMVPPresenter
import com.leakhead.foodqualityapp.ui.checker.presenter.FoodCheckerPresenter
import com.leakhead.foodqualityapp.ui.checker.view.FoodCheckerMVPView
import dagger.Module
import dagger.Provides

/**
 * Created by jyotidubey on 06/01/18.
 */
@Module
class FoodCheckerActivityModule {

    @Provides
    internal fun provideFoodCheckerInteractor(foodCheckerInteractor: FoodCheckerMVPInteractor): FoodCheckerMVPInteractor =
        foodCheckerInteractor

    @Provides
    internal fun provideFoodCheckerPresenter(foodCheckerPresenter: FoodCheckerPresenter<FoodCheckerMVPView, FoodCheckerMVPInteractor>)
            : FoodCheckerMVPPresenter<FoodCheckerMVPView, FoodCheckerMVPInteractor> = foodCheckerPresenter
}