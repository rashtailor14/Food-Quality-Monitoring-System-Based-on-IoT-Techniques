package com.leakhead.foodqualityapp.ui.checker.view

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.ui.checker.view.fragments.FoodCheckerStartFragment
import com.leakhead.foodqualityapp.util.extension.addFragment

/**
 * Created by user on 29-January-2020
 */
class FoodCheckerActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        setContentView(R.layout.activity_food_checker)
        super.onCreate(savedInstanceState)

        openAnimationFragment()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    fun openAnimationFragment() {
        supportFragmentManager.addFragment(
            R.id.fragment_container,
            FoodCheckerStartFragment.newInstance(),
            FoodCheckerStartFragment.TAG
        )
    }
}