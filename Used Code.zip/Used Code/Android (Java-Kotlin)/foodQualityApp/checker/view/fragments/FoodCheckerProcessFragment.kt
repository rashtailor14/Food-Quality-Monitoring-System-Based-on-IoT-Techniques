package com.leakhead.foodqualityapp.ui.checker.view.fragments

import android.os.Bundle
import android.os.CountDownTimer
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.common.Priority
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.JSONObjectRequestListener
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.ui.GlobalValues
import com.leakhead.foodqualityapp.ui.checker.interactor.FoodCheckerMVPInteractor
import com.leakhead.foodqualityapp.ui.checker.presenter.FoodCheckerMVPPresenter
import com.leakhead.foodqualityapp.ui.checker.view.FoodCheckerMVPView
import com.leakhead.foodqualityapp.util.extension.replaceFragment
import dagger.android.DispatchingAndroidInjector
import kotlinx.android.synthetic.main.fragment_food_checker_process.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject


/**
 * Created by user on 28-January-2020
 */
class FoodCheckerProcessFragment : Fragment() {


    companion object {

        internal val TAG = "FoodCheckerProcessFragment"
        fun newInstance(
        ): FoodCheckerProcessFragment {
            return FoodCheckerProcessFragment().apply {
            }
        }
    }

    @Inject
    lateinit var presenter: FoodCheckerMVPPresenter<FoodCheckerMVPView, FoodCheckerMVPInteractor>
    @Inject
    internal lateinit var fragmentDispatchingAndroidInjector: DispatchingAndroidInjector<Fragment>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View =
        inflater.inflate(R.layout.fragment_food_checker_process, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        presenter.onAttach(this)
        super.onViewCreated(view, savedInstanceState)

        triggerData()
    }

//    override fun setUp() {
//
//    }
//
//    override fun openAnimationFragment() {
//
//    }

    fun startTestRequest() {

        val mProgressBar: ProgressBar = this.circular_checker
        val mCountDownTimer: CountDownTimer
        var i = 3

        mProgressBar.progress = i

        mCountDownTimer = object : CountDownTimer(3000, 1000) {

            override fun onTick(millisUntilFinished: Long) {
                i--
                mProgressBar.progress = i * 100 / (3000 / 1000)
                tv_checker_timerCounter.text = i.toString()

            }

            override fun onFinish() {
                //Do what you want
                i--
                tv_checker_timerCounter.text = "0"
                mProgressBar.progress = 100

                // Navigation
                switchToFoodCheckerResultFragment()

            }


        }
        mCountDownTimer.start()
    }

    fun triggerData() {
        val jsonObject = JSONObject()

        val currentTimestamp = System.currentTimeMillis().toString()
        GlobalValues.currentId = currentTimestamp

        val date = Date()
        val formatter = SimpleDateFormat("dd-MM-yyyy")
        val strDate = formatter.format(date)

        val eatable = "Yes"

        jsonObject.put("dataId", currentTimestamp)
        jsonObject.put("myHost", GlobalValues.ipAddress)
        jsonObject.put("myPort", GlobalValues.port)
        jsonObject.put("myDB", GlobalValues.db)
        jsonObject.put("myDB", GlobalValues.db)
        jsonObject.put("foodName", GlobalValues.globalFoodName)
        jsonObject.put("foodType", GlobalValues.globalFoodType)
        jsonObject.put("testDate", eatable)

        Log.d("dpnkrlog", "triggerData (line 124): $jsonObject")

        AndroidNetworking.post("${GlobalValues.currentIPAddress}/saveSensorInfo")
            .addJSONObjectBody(jsonObject)
            .setPriority(Priority.MEDIUM)
            .build()
            .getAsJSONObject(object : JSONObjectRequestListener {
                override fun onResponse(response: JSONObject) {
                    startTestRequest()
                    Log.d("dpnkrlog", "onResponse (line 216):$response ")
                    // do anything with response
                }

                override fun onError(error: ANError) {
                    // handle error
                    Log.d("dpnkrlog", "error (line 216):$error")
                }
            })
    }

    fun switchToFoodCheckerResultFragment() {
        fragmentManager?.replaceFragment(
            R.id.fragment_container,
            FoodCheckerResultFragment.newInstance(),
            FoodCheckerResultFragment.TAG
        )

    }
}