package com.leakhead.foodqualityapp.ui.checker.view.fragments

import android.os.Bundle
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.ui.GlobalValues
import com.leakhead.foodqualityapp.util.extension.replaceFragment
import kotlinx.android.synthetic.main.fragment_food_checker_input_details.*

/**
 * Created by user on 28-January-2020
 */
class FoodICheckerInputDetailsFragment : Fragment() {

    companion object {

        internal val TAG = "FoodICheckerInputDetailsFragment"
        fun newInstance(
        ): FoodICheckerInputDetailsFragment {
            return FoodICheckerInputDetailsFragment().apply {
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View =
        inflater.inflate(R.layout.fragment_food_checker_input_details, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        presenter.onAttach(this)
        super.onViewCreated(view, savedInstanceState)



        btn_start.setOnClickListener {

            GlobalValues.globalFoodName = txt_food_name.text.toString()
            GlobalValues.globalFoodType = txt_food_type.text.toString()
            
            Log.d("dpnkrlog", "onViewCreated (line 46): ${GlobalValues.globalFoodName}")
            Log.d("dpnkrlog", "onViewCreated (line 46): ${GlobalValues.globalFoodType}")

            switchToFoodCheckerProcessFragment()


        }


    }

//    override fun setUp() {
//
//    }
//
//    override fun openAnimationFragment() {
//
//    }

    fun switchToFoodCheckerProcessFragment() {
        fragmentManager?.replaceFragment(
            R.id.fragment_container,
            FoodCheckerProcessFragment.newInstance(),
            FoodCheckerProcessFragment.TAG
        )

    }
}