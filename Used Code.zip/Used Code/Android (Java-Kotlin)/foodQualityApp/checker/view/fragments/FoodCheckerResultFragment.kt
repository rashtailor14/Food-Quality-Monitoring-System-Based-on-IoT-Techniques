package com.leakhead.foodqualityapp.ui.checker.view.fragments

import android.os.Bundle
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.common.Priority
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.JSONObjectRequestListener
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.ui.GlobalValues
import kotlinx.android.synthetic.main.fragment_food_checker_result.*
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by user on 28-January-2020
 */
class FoodCheckerResultFragment : Fragment() {

    companion object {

        internal val TAG = "FoodCheckerResultFragment"
        fun newInstance(
        ): FoodCheckerResultFragment {
            return FoodCheckerResultFragment().apply {
            }
        }
    }

//    @Inject
//    lateinit var presenter: FoodCheckerMVPPresenter<FoodCheckerMVPView, FoodCheckerMVPInteractor>
//    @Inject
//    internal lateinit var fragmentDispatchingAndroidInjector: DispatchingAndroidInjector<Fragment>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View =
        inflater.inflate(R.layout.fragment_food_checker_result, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        presenter.onAttach(this)
        super.onViewCreated(view, savedInstanceState)
        getData()

        btn_exit.setOnClickListener {
            activity?.finish()
        }
    }

    fun getData() {
        val jsonObject = JSONObject()

        jsonObject.put("dataId", GlobalValues.currentId)
        jsonObject.put("myHost", GlobalValues.ipAddress)
        jsonObject.put("myPort", GlobalValues.port)
        jsonObject.put("myDB", GlobalValues.db)

        AndroidNetworking.post("${GlobalValues.currentIPAddress}/getSensorInfo")
            .addJSONObjectBody(jsonObject)
            .setPriority(Priority.MEDIUM)
            .build()
            .getAsJSONObject(object : JSONObjectRequestListener {
                override fun onResponse(response: JSONObject) {
                    Log.d("dpnkrlog", "onResponse result (line 216):$response ")

                    val timeStamp: String = SimpleDateFormat("yyyy MM dd").format(Date())
                    val time: String = SimpleDateFormat("HH:mm").format(Date())

                    txt_name.text = response.getJSONObject("processMessage").getString("foodName")
                    txt_type.text = response.getJSONObject("processMessage").getString("foodType")
                    txt_date.text = response.getJSONObject("processMessage").getString("testDate")

                    txt_temp.text = response.getJSONObject("processMessage").getString("myTemprature")

                    txt_air.text = response.getJSONObject("processMessage").getString("airQuality")
                    txt_ph.text = response.getJSONObject("processMessage").getString("phValues")
                    txt_humidity.text = response.getJSONObject("processMessage").getString("moLevel")
                    txt_color.text = response.getJSONObject("processMessage").getString("color")
                    txt_status.text = response.getJSONObject("processMessage").getString("status")
                    // do anything with response
                }

                override fun onError(error: ANError) {
                    // handle error
                    Log.d("dpnkrlog", "error (line 216):$error ")
                }
            })
    }

//    override fun setUp() {
//
//    }
//
//    override fun openAnimationFragment() {
//
//    }
//
//    override fun startTestRequest() {
//
//    }
}