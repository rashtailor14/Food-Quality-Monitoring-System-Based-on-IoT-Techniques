package com.leakhead.foodqualityapp.ui.checker.view.fragments

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.ui.checker.interactor.FoodCheckerMVPInteractor
import com.leakhead.foodqualityapp.ui.checker.presenter.FoodCheckerMVPPresenter
import com.leakhead.foodqualityapp.ui.checker.view.FoodCheckerMVPView
import com.leakhead.foodqualityapp.util.extension.replaceFragment
import dagger.android.DispatchingAndroidInjector
import kotlinx.android.synthetic.main.fragment_food_checker_animation.*
import javax.inject.Inject

/**
 * Created by user on 28-January-2020
 */
class FoodCheckerStartFragment : Fragment() {


    companion object {

        internal val TAG = "FoodCheckerStartFragment"
        fun newInstance(
        ): FoodCheckerStartFragment {
            return FoodCheckerStartFragment().apply {
            }
        }
    }

    @Inject
    internal lateinit var layoutManager: LinearLayoutManager
    @Inject
    lateinit var presenter: FoodCheckerMVPPresenter<FoodCheckerMVPView, FoodCheckerMVPInteractor>
    @Inject
    internal lateinit var fragmentDispatchingAndroidInjector: DispatchingAndroidInjector<Fragment>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View =
        inflater.inflate(R.layout.fragment_food_checker_animation, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        presenter.onAttach(this)
        super.onViewCreated(view, savedInstanceState)
        btn_start_food_test.setOnClickListener {
            openFoodCheckerProcessFragment()
        }
    }

//    override fun setUp() {
//
//
//
//    }
//
//    override fun openAnimationFragment() {
//
//    }
//
//    override fun startTestRequest() {
//
//    }

    fun openFoodCheckerProcessFragment() {
        fragmentManager?.replaceFragment(
            R.id.fragment_container,
            FoodICheckerInputDetailsFragment.newInstance(

            ),
            FoodICheckerInputDetailsFragment.TAG
        )
    }
}