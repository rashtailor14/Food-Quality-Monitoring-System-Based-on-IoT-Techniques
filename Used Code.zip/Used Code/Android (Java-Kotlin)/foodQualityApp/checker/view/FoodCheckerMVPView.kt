package com.leakhead.foodqualityapp.ui.checker.view

import com.leakhead.foodqualityapp.ui.base.view.MVPView

/**
 * Created by user on 29-January-2020
 */
interface FoodCheckerMVPView : MVPView {

    fun openAnimationFragment(): Unit?

    fun startTestRequest(): Unit?
}