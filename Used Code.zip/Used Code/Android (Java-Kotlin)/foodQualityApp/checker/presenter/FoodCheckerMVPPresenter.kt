package com.leakhead.foodqualityapp.ui.checker.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.MVPPresenter
import com.leakhead.foodqualityapp.ui.checker.interactor.FoodCheckerMVPInteractor
import com.leakhead.foodqualityapp.ui.checker.view.FoodCheckerMVPView

/**
 * Created by user on 29-January-2020
 */
interface FoodCheckerMVPPresenter<V : FoodCheckerMVPView, I : FoodCheckerMVPInteractor> : MVPPresenter<V, I> {
}