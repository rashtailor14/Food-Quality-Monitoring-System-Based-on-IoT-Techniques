package com.leakhead.foodqualityapp.ui.checker.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.BasePresenter
import com.leakhead.foodqualityapp.ui.checker.interactor.FoodCheckerMVPInteractor
import com.leakhead.foodqualityapp.ui.checker.view.FoodCheckerMVPView
import com.leakhead.foodqualityapp.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

/**
 * Created by user on 29-January-2020
 */

class FoodCheckerPresenter<V : FoodCheckerMVPView, I : FoodCheckerMVPInteractor> @Inject internal constructor(
    interactor: I,
    schedulerProvider: SchedulerProvider,
    disposable: CompositeDisposable
) : BasePresenter<V, I>(
    interactor = interactor,
    schedulerProvider = schedulerProvider,
    compositeDisposable = disposable
),
    FoodCheckerMVPPresenter<V, I> {

}