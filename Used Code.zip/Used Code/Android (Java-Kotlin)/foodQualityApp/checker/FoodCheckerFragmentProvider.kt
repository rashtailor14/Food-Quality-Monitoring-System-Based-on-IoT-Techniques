package com.leakhead.foodqualityapp.ui.checker


import com.leakhead.foodqualityapp.ui.checker.view.fragments.FoodCheckerProcessFragment
import com.leakhead.foodqualityapp.ui.checker.view.fragments.FoodCheckerResultFragment
import com.leakhead.foodqualityapp.ui.checker.view.fragments.FoodCheckerStartFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

/**
 * Created by dpnkr on 29-August-2019
 */
@Module
internal abstract class FoodCheckerFragmentProvider {

    @ContributesAndroidInjector(modules = [FoodCheckerFragmentModule::class])
    internal abstract fun provideFoodCheckerAnimationFragmentFactory(): FoodCheckerStartFragment

    @ContributesAndroidInjector(modules = [FoodCheckerFragmentModule::class])
    internal abstract fun provideFoodCheckerProgressFragmentFactory(): FoodCheckerProcessFragment

    @ContributesAndroidInjector(modules = [FoodCheckerFragmentModule::class])
    internal abstract fun provideFoodCheckerResultFragmentFactory(): FoodCheckerResultFragment
}