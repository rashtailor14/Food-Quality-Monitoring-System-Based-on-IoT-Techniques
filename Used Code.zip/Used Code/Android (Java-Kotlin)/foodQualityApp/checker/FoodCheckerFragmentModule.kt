package com.leakhead.foodqualityapp.ui.checker


import android.support.v7.widget.LinearLayoutManager
import com.leakhead.foodqualityapp.ui.checker.interactor.FoodCheckerInteractor
import com.leakhead.foodqualityapp.ui.checker.interactor.FoodCheckerMVPInteractor
import com.leakhead.foodqualityapp.ui.checker.presenter.FoodCheckerMVPPresenter
import com.leakhead.foodqualityapp.ui.checker.presenter.FoodCheckerPresenter
import com.leakhead.foodqualityapp.ui.checker.view.FoodCheckerMVPView
import com.leakhead.foodqualityapp.ui.checker.view.fragments.FoodCheckerStartFragment
import dagger.Module
import dagger.Provides

/**
 * Created by dpnkr on 29-August-2019
 */
@Module
class FoodCheckerFragmentModule {

    @Provides
    internal fun provideFoodCheckerInteractor(interactor: FoodCheckerInteractor): FoodCheckerMVPInteractor =
        interactor

    @Provides
    internal fun provideFoodCheckerPresenter(presenter: FoodCheckerPresenter<FoodCheckerMVPView, FoodCheckerMVPInteractor>)
            : FoodCheckerMVPPresenter<FoodCheckerMVPView, FoodCheckerMVPInteractor> = presenter


    @Provides
    internal fun provideLinearLayoutManager(fragment: FoodCheckerStartFragment): LinearLayoutManager =
        LinearLayoutManager(fragment.activity)
}