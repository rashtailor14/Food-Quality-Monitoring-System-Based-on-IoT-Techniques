package com.leakhead.foodqualityapp.ui.login

import com.leakhead.foodqualityapp.ui.login.interactor.LoginInteractor
import com.leakhead.foodqualityapp.ui.login.interactor.LoginMVPInteractor
import com.leakhead.foodqualityapp.ui.login.presenter.LoginMVPPresenter
import com.leakhead.foodqualityapp.ui.login.presenter.LoginPresenter
import com.leakhead.foodqualityapp.ui.login.view.LoginMVPView
import dagger.Module
import dagger.Provides

/**
 * Created by jyotidubey on 10/01/18.
 */
@Module
class LoginActivityModule {

    @Provides
    internal fun provideLoginInteractor(interactor: LoginInteractor): LoginMVPInteractor = interactor

    @Provides
    internal fun provideLoginPresenter(presenter: LoginPresenter<LoginMVPView, LoginMVPInteractor>)
            : LoginMVPPresenter<LoginMVPView, LoginMVPInteractor> = presenter

}