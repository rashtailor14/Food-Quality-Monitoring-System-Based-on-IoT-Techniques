package com.leakhead.foodqualityapp.ui.user.view

import com.leakhead.foodqualityapp.ui.base.view.MVPView

/**
 * Created by jyotidubey on 04/01/18.
 */
interface UserMVPView : MVPView {


}