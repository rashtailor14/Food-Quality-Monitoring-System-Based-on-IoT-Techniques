package com.leakhead.foodqualityapp.ui.user.view

import android.os.Bundle
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.ui.base.view.BaseActivity
import com.leakhead.foodqualityapp.ui.user.interactor.UserMVPInteractor
import com.leakhead.foodqualityapp.ui.user.presenter.UserMVPPresenter
import kotlinx.android.synthetic.main.activity_user.*
import javax.inject.Inject

class UserMVPActivity : BaseActivity(), UserMVPView {

    @Inject
    lateinit var presenter: UserMVPPresenter<UserMVPView, UserMVPInteractor>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user)
        presenter.onAttach(this)

        btn_user_exit.setOnClickListener {
            finish()
        }
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    override fun onFragmentDetached(tag: String) {
    }

    override fun onFragmentAttached() {
    }
}
