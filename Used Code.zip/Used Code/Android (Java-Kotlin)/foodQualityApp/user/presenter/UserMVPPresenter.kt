package com.leakhead.foodqualityapp.ui.user.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.MVPPresenter
import com.leakhead.foodqualityapp.ui.user.interactor.UserMVPInteractor
import com.leakhead.foodqualityapp.ui.user.view.UserMVPView

/**
 * Created by jyotidubey on 04/01/18.
 */

interface UserMVPPresenter<V : UserMVPView, I : UserMVPInteractor> : MVPPresenter<V, I>