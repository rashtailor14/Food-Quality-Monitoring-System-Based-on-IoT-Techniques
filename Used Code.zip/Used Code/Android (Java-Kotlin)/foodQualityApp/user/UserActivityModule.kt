package com.leakhead.foodqualityapp.ui.user

import com.leakhead.foodqualityapp.ui.user.interactor.UserInteractor
import com.leakhead.foodqualityapp.ui.user.interactor.UserMVPInteractor
import com.leakhead.foodqualityapp.ui.user.presenter.UserMVPPresenter
import com.leakhead.foodqualityapp.ui.user.presenter.UserPresenter
import com.leakhead.foodqualityapp.ui.user.view.UserMVPView
import dagger.Module
import dagger.Provides

/**
 * Created by jyotidubey on 06/01/18.
 */
@Module
class UserActivityModule {

    @Provides

    internal fun provideUserInteractor(userInteractor: UserInteractor): UserMVPInteractor = userInteractor

    @Provides
    internal fun provideUserPresenter(userPresenter: UserPresenter<UserMVPView, UserMVPInteractor>)
            : UserMVPPresenter<UserMVPView, UserMVPInteractor> = userPresenter
}