package com.leakhead.foodqualityapp.ui.user.interactor

import android.content.Context
import com.leakhead.foodqualityapp.data.database.repository.device.DeviceRepo
import com.leakhead.foodqualityapp.data.database.repository.food.FoodRepo
import com.leakhead.foodqualityapp.data.database.repository.history.FoodHistoryRepo
import com.leakhead.foodqualityapp.data.database.repository.options.OptionsRepo
import com.leakhead.foodqualityapp.data.database.repository.questions.QuestionRepo
import com.leakhead.foodqualityapp.data.database.repository.sensor.SensorRepo
import com.leakhead.foodqualityapp.data.database.repository.user.UserRepo
import com.leakhead.foodqualityapp.data.network.ApiHelper
import com.leakhead.foodqualityapp.data.preferences.PreferenceHelper
import com.leakhead.foodqualityapp.ui.base.interactor.BaseInteractor
import javax.inject.Inject

/**
 * Created by jyotidubey on 04/01/18.
 */
class UserInteractor @Inject constructor(
    private val mContext: Context,
    private val questionRepoHelper: QuestionRepo,
    private val deviceRepo: DeviceRepo,
    private val foodRepo: FoodRepo,
    private val historyRepo: FoodHistoryRepo,
    private val sensorRepo: SensorRepo,
    private val userRepo: UserRepo,
    private val optionsRepoHelper: OptionsRepo,
    preferenceHelper: PreferenceHelper,
    apiHelper: ApiHelper
) : BaseInteractor(preferenceHelper, apiHelper), UserMVPInteractor {


}