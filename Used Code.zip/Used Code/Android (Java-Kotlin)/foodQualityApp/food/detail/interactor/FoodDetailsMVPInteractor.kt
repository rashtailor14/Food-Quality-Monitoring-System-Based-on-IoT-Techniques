package com.leakhead.foodqualityapp.ui.food.detail.interactor


import com.leakhead.foodqualityapp.data.network.FoodResponse
import com.leakhead.foodqualityapp.ui.base.interactor.MVPInteractor
import io.reactivex.Observable

/**
 * Created by jyotidubey on 13/01/18.
 */
interface FoodDetailsMVPInteractor : MVPInteractor {

    fun getFoodHistoryList(): Observable<FoodResponse>

}