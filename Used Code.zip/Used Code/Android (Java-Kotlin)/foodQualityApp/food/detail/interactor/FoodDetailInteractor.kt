package com.leakhead.foodqualityapp.ui.food.detail.interactor

import com.leakhead.foodqualityapp.data.network.ApiHelper
import com.leakhead.foodqualityapp.data.preferences.PreferenceHelper
import com.leakhead.foodqualityapp.ui.base.interactor.BaseInteractor
import javax.inject.Inject

/**
 * Created by jyotidubey on 13/01/18.
 */
class FoodDetailInteractor @Inject internal constructor(preferenceHelper: PreferenceHelper, apiHelper: ApiHelper) :
    BaseInteractor(preferenceHelper, apiHelper), FoodDetailsMVPInteractor {

    override fun getFoodHistoryList() = apiHelper.getFoodApiCall()

}