package com.leakhead.foodqualityapp.ui.food.detail.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.BasePresenter
import com.leakhead.foodqualityapp.ui.food.detail.interactor.FoodDetailsMVPInteractor
import com.leakhead.foodqualityapp.ui.food.detail.view.FoodDetailsMVPView
import com.leakhead.foodqualityapp.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

/**
 * Created by jyotidubey on 13/01/18.
 */
class FoodDetailsPresenter<V : FoodDetailsMVPView, I : FoodDetailsMVPInteractor> @Inject constructor(
    interactor: I,
    schedulerProvider: SchedulerProvider,
    compositeDisposable: CompositeDisposable
) : BasePresenter<V, I>(
    interactor = interactor,
    schedulerProvider = schedulerProvider,
    compositeDisposable = compositeDisposable
), FoodDetailsMVPPresenter<V, I> {

    override fun onViewPrepared() {
        getView()?.showProgress()
        interactor?.let {
            it.getFoodHistoryList()
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe { foodResponse ->
                    getView()?.let {
                        it.hideProgress()
                        it.displayFoodHistoryList(foodResponse.data)
                    }
                }
        }
    }
}