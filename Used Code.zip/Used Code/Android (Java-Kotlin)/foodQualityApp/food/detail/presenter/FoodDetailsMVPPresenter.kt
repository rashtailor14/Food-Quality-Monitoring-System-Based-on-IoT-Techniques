package com.leakhead.foodqualityapp.ui.food.detail.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.MVPPresenter
import com.leakhead.foodqualityapp.ui.food.detail.interactor.FoodDetailsMVPInteractor
import com.leakhead.foodqualityapp.ui.food.detail.view.FoodDetailsMVPView

/**
 * Created by jyotidubey on 13/01/18.
 *
 */
interface FoodDetailsMVPPresenter<V : FoodDetailsMVPView, I : FoodDetailsMVPInteractor> : MVPPresenter<V, I> {

    fun onViewPrepared()
}