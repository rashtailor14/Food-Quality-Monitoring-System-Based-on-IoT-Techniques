package com.leakhead.foodqualityapp.ui.food.detail.view

import com.leakhead.foodqualityapp.data.database.repository.food.Food
import com.leakhead.foodqualityapp.data.database.repository.history.FoodHistory
import com.leakhead.foodqualityapp.ui.base.view.MVPView

/**
 * Created by jyotidubey on 13/01/18.
 */
interface FoodDetailsMVPView : MVPView {

    fun displayFoodHistoryList(foodHistory: List<FoodHistory>?): Unit?

}