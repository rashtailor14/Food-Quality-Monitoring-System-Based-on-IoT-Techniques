package com.leakhead.foodqualityapp.ui.food.description

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import com.androidnetworking.AndroidNetworking
import com.androidnetworking.common.Priority
import com.androidnetworking.error.ANError
import com.androidnetworking.interfaces.JSONObjectRequestListener
import com.leakhead.foodqualityapp.ui.GlobalValues
import kotlinx.android.synthetic.main.activity_food_description.*
import org.json.JSONObject


class FoodDescriptionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.leakhead.foodqualityapp.R.layout.activity_food_description)

        val sessionId = intent.getStringExtra("testId")

        if (!sessionId.isNullOrEmpty()) {
            getData(sessionId)
        }

        btn_exit.setOnClickListener {
            finish()
        }


    }

    fun getData(testId: String) {
        val jsonObject = JSONObject()

        jsonObject.put("dataId", testId)
        jsonObject.put("myHost", GlobalValues.ipAddress)
        jsonObject.put("myPort", GlobalValues.port)
        jsonObject.put("myDB", GlobalValues.db)

        AndroidNetworking.post("${GlobalValues.currentIPAddress}/getSensorInfo")
            .addJSONObjectBody(jsonObject)
            .setPriority(Priority.MEDIUM)
            .build()
            .getAsJSONObject(object : JSONObjectRequestListener {
                override fun onResponse(response: JSONObject) {
                    Log.d("dpnkrlog", "onResponse result (line 216):$response ")


                    txt_name.text = response.getJSONObject("processMessage").getString("foodName")
                    txt_type.text = response.getJSONObject("processMessage").getString("foodType")
                    txt_date.text = response.getJSONObject("processMessage").getString("testDate")
                    txt_temp.text = response.getJSONObject("processMessage").getString("myTemprature")
                    txt_humidity.text = response.getJSONObject("processMessage").getString("moLevel")
                    txt_air.text = response.getJSONObject("processMessage").getString("airQuality")
                    txt_ph.text = response.getJSONObject("processMessage").getString("phValues")
                    txt_color.text = response.getJSONObject("processMessage").getString("color")
                    // do anything with response
                }

                override fun onError(error: ANError) {
                    // handle error
                    Log.d("dpnkrlog", "error (line 216):$error ")
                }
            })
    }
}
