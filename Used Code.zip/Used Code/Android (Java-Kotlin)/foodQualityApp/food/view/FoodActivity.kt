package com.leakhead.foodqualityapp.ui.food.view

import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.app.Fragment
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.ui.base.view.BaseActivity
import com.leakhead.foodqualityapp.ui.food.FoodPagerAdapter
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.support.HasSupportFragmentInjector
import kotlinx.android.synthetic.main.activity_feed.*
import kotlinx.android.synthetic.main.activity_feed.tabLayout
import kotlinx.android.synthetic.main.activity_food.*
import javax.inject.Inject

/**
 * Created by jyotidubey on 13/01/18.
 */
class FoodActivity : BaseActivity(), HasSupportFragmentInjector {

    @Inject
    internal lateinit var fragmentDispatchingAndroidInjector: DispatchingAndroidInjector<Fragment>

    internal lateinit var feedPagerAdapter: FoodPagerAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_food)
        feedPagerAdapter = FoodPagerAdapter(supportFragmentManager)
        setUpFeedPagerAdapter()
    }

    override fun onFragmentAttached() {
    }

    override fun onFragmentDetached(tag: String) {
    }

    override fun supportFragmentInjector(): AndroidInjector<Fragment>? {
        return fragmentDispatchingAndroidInjector
    }

    private fun setUpFeedPagerAdapter() {
        feedPagerAdapter.count = 1
        foodViewPager.adapter = feedPagerAdapter
        tabLayout.addTab(tabLayout.newTab().setText("Food History"))
//        tabLayout.addTab(tabLayout.newTab().setText(R.string.open_source))
        foodViewPager.offscreenPageLimit = tabLayout.tabCount;
        foodViewPager.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                feedViewPager.currentItem = tab.position
            }

            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })


    }
}