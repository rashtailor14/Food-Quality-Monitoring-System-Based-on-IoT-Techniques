package com.leakhead.foodqualityapp.ui.food.history.view

import android.content.Intent
import android.net.Uri
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.data.database.repository.history.FoodHistory
import kotlinx.android.synthetic.main.item_food_history_list.view.*


/**
 * Created by jyotidubey on 14/01/18.
 */
class FoodHistoryAdapter(private val blogListItems: MutableList<FoodHistory>) :
    RecyclerView.Adapter<FoodHistoryAdapter.FoodHistoryViewHolder>() {

    override fun getItemCount() = this.blogListItems.size

    override fun onBindViewHolder(holder: FoodHistoryViewHolder, position: Int) = holder.let {
        it.clear()
        it.onBind(position)
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int) = FoodHistoryViewHolder(
        LayoutInflater.from(parent?.context)
            .inflate(R.layout.item_food_history_list, parent, false)
    )

    internal fun addFoodHistoryToList(foodHistory: List<FoodHistory>) {
        this.blogListItems.addAll(foodHistory)
        notifyDataSetChanged()
    }

    inner class FoodHistoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun clear() {
            itemView.tv_foodName.text = ""
            itemView.foodType.text = ""
            itemView.tv_foodArea.text = ""
            itemView.tv_foodDate.text = ""
            itemView.contentArea.text = ""
        }

        fun onBind(position: Int) {

            val (id, foodId, food_name, created_at, updated_at, author) = blogListItems[position]

            inflateData(food_name, created_at, updated_at, author, author)
//            setItemClickListener(blogUrl)
        }

        private fun setItemClickListener(blogUrl: String?) {
            itemView.setOnClickListener {
                blogUrl?.let {
                    try {
                        val intent = Intent()
                        // using "with" as an example
                        with(intent) {
                            action = Intent.ACTION_VIEW
                            data = Uri.parse(it)
                            addCategory(Intent.CATEGORY_BROWSABLE)
                        }
                        itemView.context.startActivity(intent)
                    } catch (e: Exception) {
                    }
                }

            }
        }

        private fun inflateData(
            name: String?,
            type: String?,
            area: String?,
            date: String?,
            content: String?
        ) {
            name?.let { itemView.tv_foodName.text = it }
            type?.let { itemView.foodType.text = it }
            area?.let { itemView.tv_foodArea.text = it }
            date?.let { itemView.tv_foodDate.text = it }
            content?.let { itemView.contentArea.text = it }
        }

    }
}
