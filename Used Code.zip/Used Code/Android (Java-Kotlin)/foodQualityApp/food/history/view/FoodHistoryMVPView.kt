package com.leakhead.foodqualityapp.ui.food.history.view

import com.leakhead.foodqualityapp.data.database.repository.history.FoodHistory
import com.leakhead.foodqualityapp.ui.base.view.MVPView

/**
 * Created by jyotidubey on 13/01/18.
 */
interface FoodHistoryMVPView : MVPView {

    fun displayFoodHistoryList(foodHistory: List<FoodHistory>?): Unit?

    fun displayFoodHistoryListData(foodHistory: List<String>): Unit?

}