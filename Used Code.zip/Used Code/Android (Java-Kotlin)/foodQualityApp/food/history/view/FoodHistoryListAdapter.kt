package com.leakhead.foodqualityapp.ui.food.history.view

import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.ui.food.description.FoodDescriptionActivity
import kotlinx.android.synthetic.main.item_food_list.view.*


/**
 * Created by jyotidubey on 14/01/18.
 */
class FoodHistoryListAdapter(private val blogListItems: MutableList<String>) :
    RecyclerView.Adapter<FoodHistoryListAdapter.FoodHistoryViewHolder>() {

    override fun getItemCount() = this.blogListItems.size

    override fun onBindViewHolder(holder: FoodHistoryViewHolder, position: Int) = holder.let {
        it.clear()
        it.onBind(position)
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int) = FoodHistoryViewHolder(
        LayoutInflater.from(parent?.context)
            .inflate(R.layout.item_food_list, parent, false)
    )

    internal fun addFoodHistoryToList(foodHistory: List<String>) {
        this.blogListItems.addAll(foodHistory)
        notifyDataSetChanged()
    }

    inner class FoodHistoryViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun clear() {
            itemView.test_id_title.text = ""
            itemView.test_id.text = ""
        }

        fun onBind(position: Int) {

            blogListItems[position]

            inflateData("Food Test Id : ", blogListItems[position])
            setItemClickListener(blogListItems[position])

        }

        private fun setItemClickListener(testId: String?) {
            itemView.setOnClickListener {
                val intent = Intent(it.context, FoodDescriptionActivity::class.java)
                intent.putExtra("testId", testId)
                it.context.startActivity(intent)
            }
        }

        private fun inflateData(
            name: String?,
            type: String?
        ) {
            name?.let { itemView.test_id_title.text = it }
            type?.let { itemView.test_id.text = it }

        }

    }
}
