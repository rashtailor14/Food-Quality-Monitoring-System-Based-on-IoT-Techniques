package com.leakhead.foodqualityapp.ui.food.history.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.MVPPresenter
import com.leakhead.foodqualityapp.ui.food.history.interactor.FoodHistoryMVPInteractor
import com.leakhead.foodqualityapp.ui.food.history.view.FoodHistoryMVPView
import org.json.JSONObject

/**
 * Created by jyotidubey on 13/01/18.
 *
 */
interface FoodHistoryMVPPresenter<V : FoodHistoryMVPView, I : FoodHistoryMVPInteractor> : MVPPresenter<V, I> {

    fun onViewPrepared()

    fun onViewPreparedHistory(jsonObject: JSONObject)
}