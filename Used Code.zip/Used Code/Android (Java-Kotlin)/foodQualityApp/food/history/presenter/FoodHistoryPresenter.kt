package com.leakhead.foodqualityapp.ui.food.history.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.BasePresenter
import com.leakhead.foodqualityapp.ui.food.history.interactor.FoodHistoryMVPInteractor
import com.leakhead.foodqualityapp.ui.food.history.view.FoodHistoryMVPView
import com.leakhead.foodqualityapp.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import org.json.JSONObject
import javax.inject.Inject

/**
 * Created by jyotidubey on 13/01/18.
 */
class FoodHistoryPresenter<V : FoodHistoryMVPView, I : FoodHistoryMVPInteractor> @Inject constructor(
    interactor: I,
    schedulerProvider: SchedulerProvider,
    compositeDisposable: CompositeDisposable
) : BasePresenter<V, I>(
    interactor = interactor,
    schedulerProvider = schedulerProvider,
    compositeDisposable = compositeDisposable
), FoodHistoryMVPPresenter<V, I> {

    override fun onViewPrepared() {
        getView()?.showProgress()
        interactor?.let {
            it.getFoodHistoryList()
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe { foodResponse ->
                    getView()?.let {
                        it.hideProgress()
                        it.displayFoodHistoryList(foodResponse.data)
                    }
                }
        }
    }

    override fun onViewPreparedHistory(jsonObject: JSONObject) {
        getView()?.showProgress()
        interactor?.let {
            it.getFoodHistoryDataList(jsonObject)
                .compose(schedulerProvider.ioToMainObservableScheduler())
                .subscribe { foodResponse ->
                    getView()?.let {
                        it.hideProgress()
                        it.displayFoodHistoryListData(foodResponse.processMessage.toList())
                    }
                }
        }
    }
}