package com.leakhead.foodqualityapp.ui.food.history.interactor

import com.leakhead.foodqualityapp.data.network.ApiHelper
import com.leakhead.foodqualityapp.data.preferences.PreferenceHelper
import com.leakhead.foodqualityapp.ui.base.interactor.BaseInteractor
import org.json.JSONObject
import javax.inject.Inject

/**
 * Created by jyotidubey on 13/01/18.
 */
class FoodHistoryInteractor @Inject internal constructor(preferenceHelper: PreferenceHelper, apiHelper: ApiHelper) :
    BaseInteractor(preferenceHelper, apiHelper), FoodHistoryMVPInteractor {

    override fun getFoodHistoryList() = apiHelper.getFoodApiCall()

    override fun getFoodHistoryDataList(jsonObject: JSONObject) = apiHelper.getFoodHistoryApiCall(jsonObject)

}