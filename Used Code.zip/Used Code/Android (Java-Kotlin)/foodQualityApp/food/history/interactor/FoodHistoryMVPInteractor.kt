package com.leakhead.foodqualityapp.ui.food.history.interactor


import com.leakhead.foodqualityapp.data.network.FoodHistoryResponse
import com.leakhead.foodqualityapp.data.network.FoodResponse
import com.leakhead.foodqualityapp.ui.base.interactor.MVPInteractor
import io.reactivex.Observable
import org.json.JSONObject

/**
 * Created by jyotidubey on 13/01/18.
 */
interface FoodHistoryMVPInteractor : MVPInteractor {

    fun getFoodHistoryList(): Observable<FoodResponse>

    fun getFoodHistoryDataList(jsonObject: JSONObject): Observable<FoodHistoryResponse>

}