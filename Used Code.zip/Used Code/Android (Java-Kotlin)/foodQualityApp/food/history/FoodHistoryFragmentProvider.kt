package com.leakhead.foodqualityapp.ui.food.history

import com.leakhead.foodqualityapp.ui.food.history.view.FoodHistoryFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

/**
 * Created by jyotidubey on 14/01/18.
 */
@Module
internal abstract class FoodHistoryFragmentProvider {

    @ContributesAndroidInjector(modules = [FoodHistoryFragmentModule::class])
    internal abstract fun provideFoodHistoryFragmentFactory(): FoodHistoryFragment
}