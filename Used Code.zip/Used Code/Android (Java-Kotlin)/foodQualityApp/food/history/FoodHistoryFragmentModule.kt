package com.leakhead.foodqualityapp.ui.food.history

import android.support.v7.widget.LinearLayoutManager
import com.leakhead.foodqualityapp.ui.food.history.interactor.FoodHistoryInteractor
import com.leakhead.foodqualityapp.ui.food.history.interactor.FoodHistoryMVPInteractor
import com.leakhead.foodqualityapp.ui.food.history.presenter.FoodHistoryMVPPresenter
import com.leakhead.foodqualityapp.ui.food.history.presenter.FoodHistoryPresenter
import com.leakhead.foodqualityapp.ui.food.history.view.FoodHistoryFragment
import com.leakhead.foodqualityapp.ui.food.history.view.FoodHistoryListAdapter
import com.leakhead.foodqualityapp.ui.food.history.view.FoodHistoryMVPView
import dagger.Module
import dagger.Provides
import java.util.*

/**
 * Created by jyotidubey on 14/01/18.
 */
@Module
class FoodHistoryFragmentModule {

    @Provides
    internal fun provideFoodHistoryInteractor(interactor: FoodHistoryInteractor): FoodHistoryMVPInteractor = interactor

    @Provides
    internal fun provideFoodHistoryPresenter(presenter: FoodHistoryPresenter<FoodHistoryMVPView, FoodHistoryMVPInteractor>)
            : FoodHistoryMVPPresenter<FoodHistoryMVPView, FoodHistoryMVPInteractor> = presenter

    @Provides
    internal fun provideFoodHistoryAdapter(): FoodHistoryListAdapter = FoodHistoryListAdapter(ArrayList())

    @Provides
    internal fun provideLinearLayoutManager(fragment: FoodHistoryFragment): LinearLayoutManager =
        LinearLayoutManager(fragment.activity)

}