package com.leakhead.foodqualityapp.ui

import com.leakhead.foodqualityapp.BuildConfig

/**
 * Created by user on 29-January-2020
 */
object GlobalValues {

    var ipAddress: String? = "192.168.0.103"
    var port: Int? = 6379
    var db: String? = "1"

    var globalFoodName: String? = null
    var globalFoodType: String? = null
    var currentId: String? = null

    var currentIPAddress: String = BuildConfig.BASE_URL_PI
}