package com.leakhead.foodqualityapp.ui.device.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.BasePresenter
import com.leakhead.foodqualityapp.ui.device.interactor.DeviceMVPInteractor
import com.leakhead.foodqualityapp.ui.device.view.DeviceMVPView
import com.leakhead.foodqualityapp.util.SchedulerProvider
import io.reactivex.disposables.CompositeDisposable
import javax.inject.Inject

/**
 * Created by jyotidubey on 04/01/18.
 */
class DevicePresenter<V : DeviceMVPView, I : DeviceMVPInteractor> @Inject internal constructor(
    interactor: I,
    schedulerProvider: SchedulerProvider,
    disposable: CompositeDisposable
) : BasePresenter<V, I>(
    interactor = interactor,
    schedulerProvider = schedulerProvider,
    compositeDisposable = disposable
), DeviceMVPPresenter<V, I> {


}