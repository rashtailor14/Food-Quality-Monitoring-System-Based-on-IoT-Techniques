package com.leakhead.foodqualityapp.ui.device.presenter

import com.leakhead.foodqualityapp.ui.base.presenter.MVPPresenter
import com.leakhead.foodqualityapp.ui.device.interactor.DeviceMVPInteractor
import com.leakhead.foodqualityapp.ui.device.view.DeviceMVPView

/**
 * Created by jyotidubey on 04/01/18.
 */
interface DeviceMVPPresenter<V : DeviceMVPView, I : DeviceMVPInteractor> : MVPPresenter<V, I>