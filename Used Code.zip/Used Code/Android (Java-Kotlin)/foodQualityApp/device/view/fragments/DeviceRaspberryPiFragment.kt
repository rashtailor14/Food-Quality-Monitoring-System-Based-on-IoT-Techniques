package com.leakhead.foodqualityapp.ui.device.view.fragments

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import com.leakhead.foodqualityapp.R
import kotlinx.android.synthetic.main.fragment_raspberrypi.*


/**
 * Created by dpnkr on 30-September-2019
 *
 * A simple [Fragment] subclass.
 */
class DeviceRaspberryPiFragment : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        setContentView(R.layout.fragment_raspberrypi)
        super.onCreate(savedInstanceState)

        btn_frag_pi_exit.setOnClickListener {
            finish()
        }

    }

    override fun onDestroy() {
        super.onDestroy()
    }

}
