package com.leakhead.foodqualityapp.ui.device.view

import android.content.Intent
import android.os.Bundle
import com.leakhead.foodqualityapp.R
import com.leakhead.foodqualityapp.ui.base.view.BaseActivity
import com.leakhead.foodqualityapp.ui.device.interactor.DeviceMVPInteractor
import com.leakhead.foodqualityapp.ui.device.presenter.DeviceMVPPresenter
import com.leakhead.foodqualityapp.ui.device.view.fragments.DeviceESP32Fragment
import com.leakhead.foodqualityapp.ui.device.view.fragments.DeviceRaspberryPiFragment
import kotlinx.android.synthetic.main.activity_device.*
import javax.inject.Inject

class DeviceMVPActivity : BaseActivity(), DeviceMVPView {

    @Inject
    lateinit var presenter: DeviceMVPPresenter<DeviceMVPView, DeviceMVPInteractor>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_device)
        presenter.onAttach(this)

        imgV_rpi.setOnClickListener {
            openRPiFragment()
        }

        imgV_esp32.setOnClickListener {
            openESP32Fragment()
        }


        btn_exit.setOnClickListener {
            finish()
        }
    }

    override fun onDestroy() {
        presenter.onDetach()
        super.onDestroy()
    }

    override fun onFragmentDetached(tag: String) {
    }

    override fun onFragmentAttached() {
    }

    override fun showSuccessToast() {
    }

    override fun showErrorToast() {
    }

    fun openESP32Fragment() {
        val intent = Intent(this, DeviceESP32Fragment::class.java)
        startActivity(intent)
    }

    fun openRPiFragment() {
        val intent = Intent(this, DeviceRaspberryPiFragment::class.java)
        startActivity(intent)
    }
}
