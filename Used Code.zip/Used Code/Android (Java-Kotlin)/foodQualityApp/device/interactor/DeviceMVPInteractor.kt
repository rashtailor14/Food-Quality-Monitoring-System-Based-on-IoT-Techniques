package com.leakhead.foodqualityapp.ui.device.interactor

import com.leakhead.foodqualityapp.ui.base.interactor.MVPInteractor

/**
 * Created by jyotidubey on 04/01/18.
 */
interface DeviceMVPInteractor : MVPInteractor {

}