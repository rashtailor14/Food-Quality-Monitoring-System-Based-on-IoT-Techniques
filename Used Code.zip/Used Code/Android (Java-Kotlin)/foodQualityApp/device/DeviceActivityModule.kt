package com.leakhead.foodqualityapp.ui.device

import com.leakhead.foodqualityapp.ui.device.interactor.DeviceInteractor
import com.leakhead.foodqualityapp.ui.device.interactor.DeviceMVPInteractor
import com.leakhead.foodqualityapp.ui.device.presenter.DeviceMVPPresenter
import com.leakhead.foodqualityapp.ui.device.presenter.DevicePresenter
import com.leakhead.foodqualityapp.ui.device.view.DeviceMVPView
import dagger.Module
import dagger.Provides

/**
 * Created by jyotidubey on 06/01/18.
 */
@Module
class DeviceActivityModule {

    @Provides
    internal fun provideDeviceInteractor(deviceInteractor: DeviceInteractor): DeviceMVPInteractor = deviceInteractor

    @Provides
    internal fun provideDevicePresenter(devicePresenter: DevicePresenter<DeviceMVPView, DeviceMVPInteractor>)
            : DeviceMVPPresenter<DeviceMVPView, DeviceMVPInteractor> = devicePresenter
}