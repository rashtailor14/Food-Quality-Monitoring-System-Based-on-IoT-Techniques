########################################################################################################################################################################################
# Get Relevant Libraries

from flask import Flask, jsonify, request
import redis as redisDB

import RPi.GPIO as GPIO
import sensorModule.dht11 as dht11
from sensorModule.mq135 import *

import time
import datetime
import sys

########################################################################################################################################################################################
# Define Globals Here

# Create Host Object
myApp = Flask(__name__)


# initialize GPIO
GPIO.setwarnings(True)
GPIO.setmode(GPIO.BCM)


########################################################################################################################################################################################
# Define Functions

# Common Function To Push All Sensor Data
def onPutData(mData, mID, mHost, mPort, mDB):
    try:
        dbConn = redisDB.Redis(host=mHost, port=mPort, db=mDB, socket_timeout=5, socket_connect_timeout=5)
        dbConn.hmset(mID, mData)
        currIds, stat = onGetIdList(mHost, mPort, mDB)
        if stat != 900: raise Exception('Unable To Uload Data')
        currIds = [cId.decode() for cId in currIds]
        if mID not in currIds: dbConn.lpush('myIds', mID)
        return 'OK', 900
    except Exception as ex:
        return str(ex), 999


# Clear Database
def onClearDB(mHost, mPort, mDB):
    try:
        dbConn = redisDB.Redis(host=mHost, port=mPort, db=mDB, socket_timeout=5, socket_connect_timeout=5)
        dbConn.flushdb()
        return 'OK', 900
    except Exception as ex:
        return str(ex), 999


# Common Function To Gen Sensor Data
def onGetData(mID, mHost, mPort, mDB):
    try:
        dbConn = redisDB.Redis(host=mHost, port=mPort, db=mDB, socket_timeout=5, socket_connect_timeout=5)
        return dbConn.hgetall(mID), 900
    except Exception as ex:
        return str(ex), 999


# Function To Gen All Ids
def onGetIdList(mHost, mPort, mDB):
    try:
        dbConn = redisDB.Redis(host=mHost, port=mPort, db=mDB, socket_timeout=5, socket_connect_timeout=5)
        return dbConn.lrange('myIds', 0, -1), 900
    except Exception as ex:
        return str(ex), 999


# Function To Return Sensor Status
@myApp.route('/getPing')
def onPing(): return jsonify({'processError': False, 'processMessage': 'OK'})


# Function To Capture And Save Data From All Sensors
@myApp.route('/saveSensorInfo', methods=['POST'])
def onSaveSensorInfo():
    try:
        myCaller = request.get_json()

        reqData = myCaller

        upData = {}
        upData.update(onGetTempSensorData())
        upData.update(onGetHumiditySensorData())

        upData.update(reqData)
        upData.update(onGetColorSensorData())
        upData.update(onGetEastStatus())


        """
            .       Get Data From Other Sensors....
            .
            .
        
        """

        myStat, myCode = onPutData(mData=upData, mID=myCaller['dataId'], mHost=myCaller['myHost'],
                                   mPort=myCaller['myPort'], mDB=myCaller['myDB'])
        if myCode != 900: raise Exception(myStat)
        return jsonify({'processError': False, 'processMessage': 'OK'})
    except Exception as ex:
        print(' Data Upload Error :', str(ex))
        return jsonify({'processError': True, 'processMessage': str(ex)})


# Function To Retrive Sensor Data Of An Id
@myApp.route('/getSensorInfo', methods=['POST'])
def onGetSensorInfo():
    try:
        myCaller = request.get_json()

        myStat, myCode = onGetData(mID=myCaller['dataId'], mHost=myCaller['myHost'], mPort=myCaller['myPort'],
                                   mDB=myCaller['myDB'])
        if myCode != 900: raise Exception(myStat)
        myOut = {}
        for ky, vl in myStat.items(): myOut[ky.decode()] = vl.decode()

        return jsonify({'processError': False, 'processMessage': myOut})
    except Exception as ex:
        print(' Data Download Error :', str(ex))
        return jsonify({'processError': True, 'processMessage': str(ex)})


# Function To Get All Ids
@myApp.route('/getAllIds', methods=['POST'])
def onGetAllIds():
    try:
        myCaller = request.get_json()

        myStat, myCode = onGetIdList(mHost=myCaller['myHost'], mPort=myCaller['myPort'], mDB=myCaller['myDB'])
        if myCode != 900: raise Exception(myStat)
        myStat = [mid.decode() for mid in myStat]

        return jsonify({'processError': False, 'processMessage': myStat})
    except Exception as ex:
        print(' Data Download Error :', str(ex))
        return jsonify({'processError': True, 'processMessage': str(ex)})


# Clear Database
@myApp.route('/deleteAllData', methods=['POST'])
def onDeleteAllData():
    try:
        myCaller = request.get_json()

        myStat, myCode = onClearDB(mHost=myCaller['myHost'], mPort=myCaller['myPort'], mDB=myCaller['myDB'])
        if myCode != 900: raise Exception(myStat)

        return jsonify({'processError': False, 'processMessage': 'OK'})
    except Exception as ex:
        print(' Data Download Error :', str(ex))
        return jsonify({'processError': True, 'processMessage': str(ex)})


########################################################################################################################################################################################

# Define Functions To Read Data From Sensors

# Function To Read Temprature Sensor Data
def onGetTempSensorData():
    try:
        senInstance = dht11.DHT11(pin=14)
        readData = senInstance.read()
        if not readData.is_valid(): raise Exception('15')
        return {'myTemperature': str(readData.temperature)}
    except Exception as ex:
        return {'myTemprature': str(ex)}


# Function To Read Humidity Sensor Data
def onGetHumiditySensorData():
    try:
        senInstance = dht11.DHT11(pin=14)
        readData = senInstance.read()
        if not readData.is_valid(): raise Exception('90')
        return {'myHumidity': str(readData.humidity)}
    except Exception as ex:
        return {'myHumidity': str(ex)}


# Function To Read AirQuality Sensor Data
def onAirQualitySensorData():
    try:
        mq = MQ()
        perc = mq.MQPercentage()
        sys.stdout.write("\r")
        sys.stdout.write("\033[K")
        sys.stdout.write("LPG: %g ppm, CO: %g ppm, Smoke: %g ppm" % (perc["GAS_LPG"], perc["CO"], perc["SMOKE"]))
        sys.stdout.flush()
        return {'airQuality': str(perc)}
    except Exception as ex:
        return {'airQuality': str(ex)}

# Function To Read PH Sensor Data

ADS1115_REG_CONFIG_PGA_6_144V        = 0x00 # 6.144V range = Gain 2/3
ADS1115_REG_CONFIG_PGA_4_096V        = 0x02 # 4.096V range = Gain 1
ADS1115_REG_CONFIG_PGA_2_048V        = 0x04 # 2.048V range = Gain 2 (default)
ADS1115_REG_CONFIG_PGA_1_024V        = 0x06 # 1.024V range = Gain 4
ADS1115_REG_CONFIG_PGA_0_512V        = 0x08 # 0.512V range = Gain 8
ADS1115_REG_CONFIG_PGA_0_256V        = 0x0A # 0.256V range = Gain 16


from sensorModule.phSensor.DFRobot_ADS1115 import ADS1115
from sensorModule.phSensor.DFRobot_PH import DFRobot_PH

def onPhSensorData():
    try:

        ads1115 = ADS1115()
        ph      = DFRobot_PH()

        #Read your temperature sensor to execute temperature compensation
        temperature = 25
	    #Set the IIC address
        ads1115.setAddr_ADS1115(0x48)
	    #Sets the gain and input voltage range.
        ads1115.setGain(ADS1115_REG_CONFIG_PGA_6_144V)
	    #Get the Digital Value of Analog of selected channel
        adc0 = ads1115.readVoltage(0)
	    #Convert voltage to PH with temperature compensation
        PH = ph.readPH(adc0['r'],temperature)
        time.sleep(1.0)
        return {'phValues': str(PH)}
    except Exception as ex:
        return {'phValues': str(ex)}




# Function To Read Color Sensor Data
def onGetColorSensorData():
    try:
        return {'color': 'white'}
    except:
        return {'color': 'white'}

# Function To Read Color Sensor Data
def onGetEastStatus():
    try:
        return {'status': 'Ok'}
    except:
        return {'status': 'Ok'}


if __name__ == "__main__":
    # Start Here
    myApp.run(host='0.0.0.0', port=5000, debug=True)
    pass
