########################################################################################################################################################################################
# Get Relevant Libraries

from flask import Flask, jsonify, request
import redis as redisDB

import RPi.GPIO as GPIO
import sensorModule.dht11 as dht11
import sensorModule.TCS3200 as TCS3200
import sensorModule.MQ135 as MQ135
import time
import datetime

########################################################################################################################################################################################
# Define Globals Here

# Create Host Object
myApp = Flask(__name__)


# initialize GPIO
# GPIO.setwarnings(True)
# GPIO.setmode(GPIO.BCM)


########################################################################################################################################################################################
# Define Functions

# Common Function To Push All Sensor Data
def onPutData(mData, mID, mHost, mPort, mDB):
    try:
        dbConn = redisDB.Redis(host=mHost, port=mPort, db=mDB, socket_timeout=5, socket_connect_timeout=5)
        dbConn.hmset(mID, mData)
        currIds, stat = onGetIdList(mHost, mPort, mDB)
        if stat != 900: raise Exception('Unable To Uload Data')
        currIds = [cId.decode() for cId in currIds]
        if mID not in currIds: dbConn.lpush('myIds', mID)
        return 'OK', 900
    except Exception as ex:
        return str(ex), 999


# Clear Database
def onClearDB(mHost, mPort, mDB):
    try:
        dbConn = redisDB.Redis(host=mHost, port=mPort, db=mDB, socket_timeout=5, socket_connect_timeout=5)
        dbConn.flushdb()
        return 'OK', 900
    except Exception as ex:
        return str(ex), 999


# Common Function To Gen Sensor Data
def onGetData(mID, mHost, mPort, mDB):
    try:
        dbConn = redisDB.Redis(host=mHost, port=mPort, db=mDB, socket_timeout=5, socket_connect_timeout=5)
        return dbConn.hgetall(mID), 900
    except Exception as ex:
        return str(ex), 999


# Function To Gen All Ids
def onGetIdList(mHost, mPort, mDB):
    try:
        dbConn = redisDB.Redis(host=mHost, port=mPort, db=mDB, socket_timeout=5, socket_connect_timeout=5)
        return dbConn.lrange('myIds', 0, -1), 900
    except Exception as ex:
        return str(ex), 999


# Function To Return Sensor Status
@myApp.route('/getPing')
def onPing(): return jsonify({'processError': False, 'processMessage': 'OK'})


# Function To Capture And Save Data From All Sensors
@myApp.route('/saveSensorInfo', methods=['POST'])
def onSaveSensorInfo():
    try:
        myCaller = request.get_json()

        reqData = myCaller

        upData = {}
        upData.update(onGetTempSensorData())
        upData.update(onGetAirSensorData())
        upData.update(onGetPhSensorData())
        upData.update(onGetHumiditySensorData())
        upData.update(onGetColorSensorData())
        upData.update(reqData)

        """
            .       Get Data From Other Sensors....
            .
            .
        
        """

        myStat, myCode = onPutData(mData=upData, mID=myCaller['dataId'], mHost=myCaller['myHost'],
                                   mPort=myCaller['myPort'], mDB=myCaller['myDB'])
        if myCode != 900: raise Exception(myStat)
        return jsonify({'processError': False, 'processMessage': 'OK'})
    except Exception as ex:
        print(' Data Upload Error :', str(ex))
        return jsonify({'processError': True, 'processMessage': str(ex)})


# Function To Retrive Sensor Data Of An Id
@myApp.route('/getSensorInfo', methods=['POST'])
def onGetSensorInfo():
    try:
        myCaller = request.get_json()

        myStat, myCode = onGetData(mID=myCaller['dataId'], mHost=myCaller['myHost'], mPort=myCaller['myPort'],
                                   mDB=myCaller['myDB'])
        if myCode != 900: raise Exception(myStat)
        myOut = {}
        for ky, vl in myStat.items(): myOut[ky.decode()] = vl.decode()

        return jsonify({'processError': False, 'processMessage': myOut})
    except Exception as ex:
        print(' Data Download Error :', str(ex))
        return jsonify({'processError': True, 'processMessage': str(ex)})


# Function To Get All Ids
@myApp.route('/getAllIds', methods=['POST'])
def onGetAllIds():
    try:
        myCaller = request.get_json()

        myStat, myCode = onGetIdList(mHost=myCaller['myHost'], mPort=myCaller['myPort'], mDB=myCaller['myDB'])
        if myCode != 900: raise Exception(myStat)
        myStat = [mid.decode() for mid in myStat]

        return jsonify({'processError': False, 'processMessage': myStat})
    except Exception as ex:
        print(' Data Download Error :', str(ex))
        return jsonify({'processError': True, 'processMessage': str(ex)})


# Clear Database
@myApp.route('/deleteAllData', methods=['POST'])
def onDeleteAllData():
    try:
        myCaller = request.get_json()

        myStat, myCode = onClearDB(mHost=myCaller['myHost'], mPort=myCaller['myPort'], mDB=myCaller['myDB'])
        if myCode != 900: raise Exception(myStat)

        return jsonify({'processError': False, 'processMessage': 'OK'})
    except Exception as ex:
        print(' Data Download Error :', str(ex))
        return jsonify({'processError': True, 'processMessage': str(ex)})


########################################################################################################################################################################################

# Define Functions To Read Data From Sensors

# Function To Read Temprature Sensor Data
def onGetTempSensorData():
    try:
        senInstance = dht11.DHT11(pin=14)
        readData = senInstance.read()
        if not readData.is_valid(): raise Exception('15')
        return {'myTemperature': str(readData.temperature)}
    except Exception as ex:
        return {'myTemprature': str(ex)}


# Function To Read Humidity Sensor Data
def onGetHumiditySensorData():
    try:
        senInstance = dht11.DHT11(pin=14)
        readData = senInstance.read()
        if not readData.is_valid(): raise Exception('90')
        return {'myHumidity': str(readData.humidity)}
    except Exception as ex:
        return {'myHumidity': str(ex)}


def rawSensor():
    try:
        return {'dummySensor': 'Some_Valid_Data'}
    except:
        return {'dummySensor': 'Error_String'}


# Function To Read Air Sensor Data
def onGetAirSensorData():
    try:
        senInstance = MQ135.MQ135(pin=133)
        readData = senInstance.read()
        if not readData.is_valid(): raise Exception('90')
        return {'airQuality': str(readData.humidity)}
    except Exception as ex:
        return {'airQuality': str(ex)}


# Function To Read PH Values Data
def onGetPhSensorData():
    try:
        senInstance = MQ135.MQ135(pin=133)
        readData = senInstance.read()
        if not readData.is_valid(): raise Exception('90')
        return {'phValues': str(readData.humidity)}
    except Exception as ex:
        return {'phValues': str(ex)}


# Function To Read Color Sensor Data
def onGetColorSensorData():
    try:
        senInstance = TCS3200.3200(pin=16)
        readData = senInstance.read()
        if not readData.is_valid(): raise Exception('90')
        return {'color': str(readData.humidity)}
    except Exception as ex:
        return {'color': str(ex)}


# .
# .
# Add More Function For Each Sensor

########################################################################################################################################################################################

if __name__ == "__main__":
    # Start Here
    myApp.run(host='0.0.0.0', port=5000, debug=True)
    pass
